'use strict';
module.exports = (sequelize, DataTypes) => {
  const HoursForMonth = sequelize.define('HoursForMonth', {
    year: DataTypes.INTEGER,
    month: DataTypes.INTEGER,
    hoursToComplete: DataTypes.INTEGER
  }, {});
  HoursForMonth.associate = function(models) {
    // associations can be defined here
  };
  return HoursForMonth;
};