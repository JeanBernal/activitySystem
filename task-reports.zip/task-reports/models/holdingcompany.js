'use strict';
module.exports = (sequelize, DataTypes) => {
  const HoldingCompany = sequelize.define('HoldingCompany', {
    name: DataTypes.STRING,
    description: DataTypes.STRING,
    status_id: DataTypes.INTEGER
  }, {});
  HoldingCompany.associate = function(models) {
    Project.belongsTo(models.Project,{
      foreignKey: 'id'
    })
  };
  return HoldingCompany;
};