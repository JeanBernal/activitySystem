'use strict';
module.exports = (sequelize, DataTypes) => {
  const CampaignPhaseUser = sequelize.define('CampaignPhaseUser', {
    campaign_id: DataTypes.INTEGER,
    phase_id: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER,
    project_id:DataTypes.INTEGER,
    start_date: DataTypes.DATE,
    delivery_date: DataTypes.DATE,
    real_date: DataTypes.DATE,
    estimated_hours: DataTypes.INTEGER,
    part_rate: DataTypes.FLOAT,
    total_cost: DataTypes.INTEGER,
    gross_cost: DataTypes.INTEGER,
    status_id: DataTypes.INTEGER
  }, {});
  CampaignPhaseUser.associate = function(models) {
    // associations can be defined here
    // CampaignPhaseUser.belongsTo(models.User,{
    //   foreignKey:'id'
    // }),
    // CampaignPhaseUser.belongsTo(models.Campaign,{
    //   foreignKey:'id'
    // }),
    // CampaignPhaseUser.belongsTo(models.Phase,{
    //   foreignKey:'id'
    // })
  };
  return CampaignPhaseUser;
};