'use strict';
module.exports = (sequelize, DataTypes) => {
  const Task = sequelize.define('Task', {
    user_id: DataTypes.INTEGER,
    date: DataTypes.DATE,
    day: DataTypes.INTEGER,
    month: DataTypes.INTEGER,
    year: DataTypes.INTEGER,
    project_id: DataTypes.INTEGER,
    campaign_id: DataTypes.INTEGER,
    phase_id: DataTypes.INTEGER,
    activity: DataTypes.STRING,
    hours: DataTypes.INTEGER,
    id_task: DataTypes.INTEGER
  }, {});
  Task.associate = function(models) {
    // associations can be defined here
    Task.hasOne(models.User,{
      foreignKey: 'id'
    }),
    Task.hasOne(models.Project,{
      foreignKey: 'id'
    }),
    Task.hasOne(models.Campaign,{
      foreignKey: 'id'
    }),
    Task.hasOne(models.Phase,{
      foreignKey: 'id'
    })
  };
  return Task;
};