"use restrict"

const mongoose = require('mongoose')


const monthHoursSchema = new mongoose.Schema({
    year: {
        type: Number,
        default: new Date().getFullYear()
    },
    month: {
        type: Number,
        default: new Date().getMonth()+1
    },
    hours: {
        type: Number
    },
    created_at: {
        type: Date,
        default: Date.now
      },
    updated_at: {
        type: Date,
        default: null
      }

})

module.exports = mongoose.model('MonthHours', monthHoursSchema)