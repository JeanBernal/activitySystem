'use strict';
module.exports = (sequelize, DataTypes) => {
  const ContractType = sequelize.define('ContractType', {
    name: DataTypes.STRING,
    description: DataTypes.STRING
  }, {});
  ContractType.associate = function(models) {
    // associations can be defined here
  };
  return ContractType;
};