'use strict';
module.exports = (sequelize, DataTypes) => {
  const Unity = sequelize.define('Unitys', {
    name: DataTypes.STRING,
    description: DataTypes.STRING,
    status_id: DataTypes.INTEGER
  }, {});
  Unity.associate = function(models) {
    // associations can be defined here
    Unity.belongsToMany(models.Project,{
      trough:'unity_client_project',
      foreignKey: 'id'
    }),
    Unity.belongsToMany(models.Client,{
      trough:'unity_client_project',
      foreignKey: 'id'
    })

  };
  return Unity;
};