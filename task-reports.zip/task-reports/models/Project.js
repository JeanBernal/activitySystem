"use restrict"

const mongoose = require('mongoose')

const projectSchema = new mongoose.Schema({
    user: {
        type: String,
        min: 1,
        max: 255
    },
    project_name: {
        type: String,
        min: 1,
        max: 255
    },
    holding_company: {
        type: String,
        min: 1,
        max: 255
    },
    unit: {
        type: String,
        min: 1,
        max: 255
    },
    client: {
        type: String,
        min: 1,
        max: 255
    },
    nit: {
        type: String,
        min: 1,
        max: 255
    },
    category: {
        type: String,
        min: 1,
        max: 255
    },
    sub_category: {
        type: Array
    },
    objective_project: {
        type: String,
        min: 1,
        max: 255
    },
    use_type: {
        type: String,
        min: 1,
        max: 255
    },    
    intellectual_property: {
        type: String,
        min: 1,
        max: 255
    },
    licensed: {
        type: String,
        min: 1,
        max: 255
    },
    finality: {
        type: String,
        min: 1,
        max: 255
    },
    monthly_fee: {
        type: String,
        min: 1,
        max: 255
    },
    monthly_fee_cost: {
        type: Number
    },
    cost_center: {
        type: String,
        min: 1,
        max: 255
    },
    start_date: {
        type: Date
    },
    estimated_delivery_date: {
        type: Date
    },
    real_delivery_date: {
        type: Date
    },
    estimated_hours_disigning: {
        type: Number
    },
    estimated_hours_coding: {
        type: Number
    },
    estimated_hours_production: {
        type: Number
    },
    estimated_hours_investigation: {
        type: Number
    },
    estimated_hours_prube: {
        type: Number
    },
    estimated_hours_maintenance: {
        type: Number
    },
    updates: {
        type: String,
        min: 1,
        max: 255
    },
    estimated_hours_updates: {
        type: Number
    },
    assigned_developers: {
        type: String,
        min: 1,
        max: 255
    },
    created_at: {
        type: Date,
        default: Date.now
      },
    updated_at: {
        type: Date,
        default: null
      }

})

module.exports = mongoose.model('Project', projectSchema)