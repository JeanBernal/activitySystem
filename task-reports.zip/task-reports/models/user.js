'use strict';

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    name: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    rol_id: DataTypes.INTEGER,
    profile_id: DataTypes.INTEGER,
    status_id: DataTypes.INTEGER

  }, {});
  User.associate = function(models) {
    // associations can be defined here
    User.HasOne(models.Rol,{
      // trough: 'Rol',
      // as: 'user_rol',
      foreignKey: 'id'
    }),
    User.HasOne(models.Profile,{
      foreignKey: 'id'
    }),
    User.belongsToMany(models.Project,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    User.belongsToMany(models.Campaign,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    User.belongsToMany(models.Phase,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    })
  };
  return User;
};