'use strict';
module.exports = (sequelize, DataTypes) => {
  const Re = sequelize.define('Re', {
    rol_name: DataTypes.STRING,
    description: DataTypes.STRING
  }, {});
  Re.associate = function(models) {
    // associations can be defined here
  };
  return Re;
};