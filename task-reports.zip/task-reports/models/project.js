'use strict';
module.exports = (sequelize, DataTypes) => {
  const Project = sequelize.define('Project', {
    cost_center_id: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER,
    name: DataTypes.STRING,
    holding_company_id: DataTypes.INTEGER,
    nit: DataTypes.INTEGER,
    category: DataTypes.STRING,
    objective_project: DataTypes.STRING,
    use_type: DataTypes.STRING,
    intellectual_property: DataTypes.STRING,
    licensed: DataTypes.STRING,
    finality: DataTypes.STRING,
    monthly_fee: DataTypes.STRING,
    monthly_fee_cost: DataTypes.INTEGER,
    status_id: DataTypes.INTEGER,
  }, {});
  Project.associate = function(models) {
    // associations can be defined here
    Project.hasOne(models.CostCenter,{
      // trough: 'Rol',
      // as: 'user_rol',
      foreignKey: 'id'
    }),
    Project.hasOne(models.HoldingCompany,{
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.Unity,{
      trough:'unity_client_project',
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.Client,{
      trough:'unity_client_project',
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.User,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.Phase,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.Campaign,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Project.belongsToMany(models.unity_client_project,{
      trough: 'unity_client_project',
      foreignKey: 'id'
    })
  };
  return Project;
};