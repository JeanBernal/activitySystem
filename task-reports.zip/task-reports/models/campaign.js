'use strict';
module.exports = (sequelize, DataTypes) => {
  const Campaign = sequelize.define('Campaign', {
    project_id: DataTypes.INTEGER,
    client_id: DataTypes.INTEGER,
    name: DataTypes.STRING,
    description: DataTypes.STRING,
    status_id: DataTypes.INTEGER
  }, {});
  Campaign.associate = function(models) {
    // associations can be defined here
    // Campaign.belongsTo(models.Client,{
    //   foreignKey: 'id'
    // }),
    Campaign.hasOne(models.project_id,{
      foreignKey: 'id'
    }),
    Campaign.belongsToMany(models.Phase,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Campaign.belongsToMany(models.User,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Campaign.belongsToMany(models.Project,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    })
  };
  return Campaign;
};