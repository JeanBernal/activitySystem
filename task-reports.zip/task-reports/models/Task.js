"use restrict"

const mongoose = require('mongoose')

const taskSchema = new mongoose.Schema({
    
    user: {
        type: String,
        min: 4,
        max: 255
    },
    date: {
        type: Date        
      },
    project: {
        type: String,
        min: 1,
        max: 255
    },
    sub_category: {
        type: String,
        min: 1,
        max: 255
    },    
    phase: {
        type: String,
        min: 1,
        max: 255
    },
    activity: {
        type: String,
        min: 3,
        max: 255
    },
    id_task:{
        type: Number
    },
    hours: {
        type: Number
    },
    fulfillment: {
        type: Number,
        default: 0
    },
    created_at: {
        type: Date,
        default: Date.now
      },
    updated_at: {
        type: Date,
        default: null
      },

})

module.exports = mongoose.model('Task', taskSchema)