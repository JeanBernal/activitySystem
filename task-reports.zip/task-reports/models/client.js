'use strict';
module.exports = (sequelize, DataTypes) => {
  const Client = sequelize.define('Client', {
    name: DataTypes.STRING,
    description: DataTypes.STRING,
    status_id: DataTypes.INTEGER
  }, {});
  Client.associate = function(models) {
    // associations can be defined here
    Client.belongsToMany(models.Project,{
      trough:'unity_client_project',
      foreignKey: 'id'
    }),
    Client.belongsToMany(models.Unity,{
      trough:'unity_client_project',
      foreignKey: 'id'
    })
  };
  return Client;
};