'use strict';
module.exports = (sequelize, DataTypes) => {
  const Phase = sequelize.define('Phase', {
    name: DataTypes.STRING,
    description: DataTypes.STRING
  }, {});
  Phase.associate = function(models) {
    // associations can be defined here
    Phase.belongsToMany(models.Campaign,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Phase.belongsToMany(models.User,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    }),
    Phase.belongsToMany(models.Project,{
      trough: 'CampaignPhaseUser',
      foreignKey: 'id'
    })
  };
  return Phase;
};