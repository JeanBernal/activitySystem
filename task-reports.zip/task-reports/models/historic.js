'use strict';
module.exports = (sequelize, DataTypes) => {
  const Historic = sequelize.define('Historic', {
    project_id: DataTypes.INTEGER,
    project_name: DataTypes.STRING,
    unity_id: DataTypes.INTEGER,
    unity_name: DataTypes.STRING,
    client_id: DataTypes.INTEGER,
    client_name: DataTypes.STRING,
    campaign_id: DataTypes.INTEGER,
    campaign_name: DataTypes.STRING,
    user_id: DataTypes.INTEGER,
    user_name: DataTypes.STRING,
    user_salary: DataTypes.DOUBLE,
    task_id: DataTypes.INTEGER,
    task_activity: DataTypes.STRING,
    task_hours: DataTypes.FLOAT,
    task_date: DataTypes.DATE,
    task_day: DataTypes.INTEGER,
    task_month: DataTypes.INTEGER,
    task_year: DataTypes.INTEGER,
    user_cost: DataTypes.INTEGER,
    phase_name: DataTypes.STRING,
    hoursDistribution: DataTypes.DOUBLE,
  }, {});
  Historic.associate = function(models) {
    // associations can be defined here
  };
  return Historic;
};