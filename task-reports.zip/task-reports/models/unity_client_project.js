'use strict';
module.exports = (sequelize, DataTypes) => {
  const unity_client_project = sequelize.define('unity_client_projects', {
    unity_id: DataTypes.INTEGER,
    client_id: DataTypes.INTEGER,
    project_id: DataTypes.INTEGER,
    status_id: DataTypes.INTEGER
  }, {});
  unity_client_project.associate = function(models) {
    // associations can be defined here
  };
  return unity_client_project;
};