'use strict';
module.exports = (sequelize, DataTypes) => {
  const PhaseCampaign = sequelize.define('PhaseCampaign', {
    phase_id: DataTypes.INTEGER,
    campaign_id: DataTypes.INTEGER
  }, {});
  PhaseCampaign.associate = function(models) {
    // associations can be defined here
  };
  return PhaseCampaign;
};