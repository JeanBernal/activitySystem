"use strict";
module.exports = (sequelize, DataTypes) => {
  const Detail = sequelize.define(
    "Detail",
    {
      user_id: DataTypes.INTEGER,
      total_salary: DataTypes.INTEGER,
      gross_salary: DataTypes.INTEGER,
      additional_cost: DataTypes.INTEGER,
      date_admission: DataTypes.DATE,
      business_unit: DataTypes.STRING,
      contract_type_id: DataTypes.INTEGER
    },
    {}
  );
  Detail.associate = function(models) {
    // associations can be defined here
    Detail.HasOne(models.User,{
      foreignKey:'id'
    })
  };
  return Detail;

};
