var nodemailer = require("nodemailer");
const path = require('path')
//const user = require(path.join(__dirname, "../controllers/userController"));


function info(us){
  console.log(us)
}

  //Creamos el objeto de transporte
  var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "jeanbernalsierra@gmail.com",
      pass: ""
    }
  });

  var mensaje = "Hola desde nodejs...";

  var mailOptions = {
    from: "jeanbernalsierra@gmail.com",
    to: "jeanbernalsierra@gmail.com",
    subject: "Asunto Del Correo",
    text: mensaje
  };

 
  try {
    console.log("intro")
    transporter.sendMail(mailOptions, function(error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Email enviado: " + info.response);
      }
    });
  } catch (error) {
    console.log(error)
  }

 

//  module.exports = {
//   sendMail
// };