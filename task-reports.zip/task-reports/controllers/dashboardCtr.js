var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const Project = require("../models/project")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const Tasks = require("../models/task")(sequelize, DataTypes);
const Upc = require("../models/campaignphaseuser")(sequelize, DataTypes);
const Detail = require("../models/detail")(sequelize,DataTypes)

function filterProjects(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(async user => {
    if (user.length == 0) {
      return res.status(401).json({
        message: "No tiene permiso para traer la información"
      });
    }
    console.log(req.params.id);
    if (req.params.id != null && req.params.id != undefined) {
      users = await getUserProjects(req.params.id);
      console.log(users);
      res.json({
        message: users
      });
    }
  });
}

function getUserProjects(id) {
  console.log("Está sacando los usuarios del proyecto");
  Detail.belongsTo(User,{foreignKey:"user_id"});
  User.hasMany(Upc, { foreignKey: "id" });
  User.hasOne(Detail, { foreignKey: "id" });
  Upc.belongsTo(User, { foreignKey: "user_id" });
  return (users = User.findAll({
    include: [
        { 
            model: Upc, 
            where: {
                project_id: 1
            },
            required: true
        },
        {
            model: Detail,
            required: false
        }
    ]
  }));
}

module.exports = {
  filterProjects
};
