var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const ContractType = require("../models/contracttype")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);

function store(req, res) {
  console.log("Creando nuevo tipo de contrato");
  try {
    User.findAll({
      where: {
        id: req.params.userId
      }
    })
      .then(user => {
        if (user.length <= 0) {
          console.log("No se encontró el usuario");
          return res.status(401).json({
            cod: 2,
            message: "No tiene permiso para crear el tipo de contrato"
          });
        }
        if (user[0].rol_id != 1) {
          console.log(
            "El usuario no tiene permiso para crear un tipo de contrato"
          );
          return res.status(401).json({
            cod: 2,
            message: "No tiene permiso para crear el tipo de contrato"
          });
        }
        if (
          req.body.name == null ||
          req.body.name == undefined ||
          req.body.name == "" ||
          req.body.description == null ||
          req.body.description == undefined ||
          req.body.description == ""
        ) {
          console.log("Datos incorrectos");
          return res.status(400).json({
            cod: 3,
            message: "Los campos nombre y descripción son obligatorios"
          });
        }
        ContractType.findAll({
          where: {
            name: req.body.name
          }
        })
          .then(contract => {
            console.log(JSON.stringify(contract));
            if (contract.length > 0) {
              console.log("Ya existe un tipo de contraro con ese nombre");
              return res.status(400).json({
                cod: 4,
                message: "Ya existe un tipo de contrato con ese nombre"
              });
            }
            const contractType = ContractType.build({
              name: req.body.name,
              description: req.body.description
            });
            contractType.save().then(resp => {
              if (resp == false) {
                console.log(
                  "Ocurrió un error no identificado con la base de datos al crear el tipo de contrato"
                );
                return res.status(500).json({
                  cod: 6,
                  message:
                    "Ocurrió un error no identificado con la base de datos al crear el tipo de contrato"
                });
              }
              console.log("El tipo de contrato se creó correctamente");
              return res.status(201).json({
                cod: 0,
                message: contractType
              });
            });
          })
          .catch(err => {
            console.log(
              "Salió un error consultando los tipos de contrato: " + err
            );
            return res.status(400).json({
              cod: 5,
              message: "Salió un error consultando los tipos de contrato"
            });
          });
      })
      .catch(err => {
        console.log("Erro no capturado al crear el tipo de contraro: " + err);
        return res.status(500).json({
          cod: 1,
          message: "Error no capturado al crear el tipo de contrato"
        });
      });
  } catch (error) {
    console.log(error);
  }
}

function index(req, res) {
  console.log("Trayendo todos los tipos de contrato");
  try {
    mensajeResponse = "";
    User.findAll({
      where: {
        id: req.params.userId
      }
    })
      .then(user => {
        console.log("hizo la consulta de usuario");
        if (user.length <= 0) {
          mensajeResponse = "No tiene permiso para traer la información";
          console.log(mensajeResponse + ": " + err);
          return res.status(401).json({
            cod: 3,
            message: mensajeResponse
          });
        }
        ContractType.findAll({
          attributes: [['id','key'], 'name', 'description']
        })
          .then(contracts => {
            console.log('Hizo la consulta de contratos');
            res.json({
              data:contracts
            })
          })
          .catch(err => {
            mensajeResponse =
              "Ocurrió un error no identificado con la base de datos al traer los tipos de contrato";
            console.log(mensajeResponse + ": " + err);
            return res.status(500).json({
              cod: 2,
              message: mensajeResponse
            });
          });
      })
      .catch(err => {
        mensajeResponse =
          "Ocurrió un error no identificado al consultar el usuario";
        console.log(mensajeResponse + ": " + err);
        return res.status(500).json({
          cod: 1,
          message: mensajeResponse
        });
      });
  } catch (error) {
    mensajeResponse =
      "Ocurrió un error no identificado al traer los tipos de contrato";
    console.log(mensajeResponse + ": " + error);
    return res.status(500).json({
      cod: 1,
      message: mensajeResponse
    });
  }
}

module.exports = {
  store,
  index
};
