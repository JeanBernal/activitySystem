const bcrypt = require('bcrypt')
const path = require('path')
const jwt = require('jsonwebtoken')
var DataTypes = require('sequelize/lib/data-types');
var connection = require("../config/db");
var sequelize = require('../config/db.js')
const CostCenter = require('../models/costcenter')(sequelize, DataTypes)
const User = require('../models/user')(sequelize, DataTypes)


function store(req, res){
console.log(req.params);
User.findAll({
  where: {
    id: req.params.id
  }
}).then(user =>{
  if(!user){
    return res.status(500).json({
      message: "user not found"
    })
  }else if(user[0].rol_id  != 1){
    return res.status(401).json({
      message: "Unauthorized"
    })
  }
})
  try {
    console.log('Entró al método')
    const costCenter = CostCenter.build({
      name:req.body.name,
      description: req.body.description
    });
    costCenter.save().then(resp => {
      res.status(201).json({
        message: "Rol has been created succesfully"
      })
    });
  } catch (error) {
    console.log(error)
  }
}

function index (req, res) {
  User.findAll({
    where:{
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  CostCenter.findAll({
    where:{
      status_id: 1
    }
  }).then(data=>{
    res.json({
      data:data
    })
  })
}
//Mostrar usuairo por id
function show (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  CostCenter.findAll({where: {id: req.params.id} }).then(resp=>{
    res.json({
      data: resp
    })
  })
}
//Actualizar usuario
function update (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  try {
    CostCenter.update(
      {name: req.body.name,
       description: req.body.description
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update =>{
      res.json({
        message:"Rol has been updated"
      })
    })
  } catch (error) {
    console.log(errror)
  }
}
//Eliminar usuario
function destroy (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  CostCenter.destroy({
    where: {
      id:req.params.id
    }
  })
}

function changeStatus(req, res) {
  console.log('Método para eliminar centro de costos ' +req.params.id);
  try {
    CostCenter.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado de centro de costos");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar el centro de costos",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  changeStatus
}