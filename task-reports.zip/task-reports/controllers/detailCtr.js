const bcrypt = require('bcrypt')
const path = require('path')
const jwt = require('jsonwebtoken')
var DataTypes = require('sequelize/lib/data-types');
var connection = require("../config/db");
var sequelize = require('../config/db.js')
const Detail = require('../models/detail')(sequelize, DataTypes)
const User = require('../models/user')(sequelize, DataTypes)


function store(req, res){
User.findAll({
  where: {
    id: req.params.id
  }
}).then(user =>{
  //console.log(user[0].id)
  if(!user){
    return res.status(500).json({
      message: "user not found"
    })
  }else if(user[0].rol_id  != 1){
    return res.status(401).json({
      message: "Unauthorized"
    })
  }
})
  try {
    console.log('Entró al método')
    const detail = Detail.build({
      user_id:req.body.user_id,
      total_salary:req.body.total_salary,
      gross_salary:req.body.total_salary,
      additional_cost:req.body.additional_cost,
      date_admission:req.body.date_admission,
      bussiness_unit:req.body.bussiness_unit,
      contract_type:req.body.contract_type
    });
    detail.save().then(resp => {
      res.status(201).json({
        message: "Profile has been created succesfully"
      })
    });
  } catch (error) {
    console.log(error)
  }
}

function index (req, res) {
  User.findAll({
    where: {
      id: req.params.id
    }   
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Detail.findAll({

  }).then(data=>{
    res.json({
      data:data
    })
  })
}
//Mostrar usuairo por id
function show (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Detail.findAll({where:{id: req.params.id } }).then(resp=>{
    res.json({
      data: resp
    })
  })
}
//Actualizar usuario
function update (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  try {
    Detail.update(
      { 
        user_id:req.body.user_id,
        total_salary:req.body.total_salary,
        gross_salary:req.body.total_salary,
        additional_cost:req.body.additional_cost,
        date_admission:req.body.date_admission,
        bussiness_unit:req.body.bussiness_unit,
        contract_type:req.body.contract_type
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update =>{
      res.json({
        message:"Rol has been updated"
      })
    })
  } catch (error) {
    console.log(errror)
  }
}
//Eliminar usuario
function destroy (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Detail.destroy({
    where: {
      id:req.params.id
    }
  })
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store
}