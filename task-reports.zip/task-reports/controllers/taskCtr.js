const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const Task = require("../models/task")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const Phase = require("../models/phase")(sequelize, DataTypes);
const HoursForMonth = require("../models/hoursformonth")(sequelize, DataTypes);
const Project = require("../models/project")(sequelize, DataTypes);
const Campaign = require("../models/campaign")(sequelize, DataTypes);
const Historic = require("../models/historic")(sequelize, DataTypes);
const HistoricCtr = require("./historicCtr");

function store(req, res) {
  console.log("vamos bien");
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(async user => {
    //console.log(user[0].id)
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
    try {
      console.log("Entró al método");
      idTask = null;
      if (
        req.body.idTask != null &&
        req.body.idTask != undefined &&
        req.body.idTask != ""
      ) {
        idTask = req.body.idTask;
      }
      console.log(
        "*******************************************************Tamaño de las campañas: " +
          req.body.campaign.length
      );
      for (let i = 0; i < req.body.campaign.length; i++) {
        console.log(i);
        //  let message = await procesStore(req.body.campaign[i],req.body.campaign.length,req.body.hours,req.body.date,req.body.project,
        //     req.body.phase,req.body.activity,idTask,req.params.userId);
        let hours = req.body.hours / req.body.campaign.length;
        const task = Task.build({
          user_id: req.body.userId,
          date: req.body.date,
          day: new Date(req.body.date).getDate(),
          month: new Date(req.body.date).getMonth() + 1,
          year: new Date(req.body.date).getFullYear(),
          project_id: req.body.project,
          campaign_id: req.body.campaign[i],
          phase_id: req.body.phase,
          activity: req.body.activity,
          hours: hours,
          id_task: idTask
        });
        console.log("datos agregados");
        await task.save().then(resp => {
          console.log("Todo perfecto");
        });
        await HistoricCtr.historyData2(task.id);
      }
      res.status(201).json({
        message: "Task created"
      });
    } catch (error) {
      console.log(error);
    }
  });
}

async function procesStore(
  camp,
  number,
  hours2,
  date,
  project,
  phase,
  activity,
  idTask,
  userId
) {
  let hours = hours2 / number;
  const task = Task.build({
    user_id: userId,
    date: date,
    day: new Date(date).getDate(),
    month: new Date(date).getMonth() + 1,
    year: new Date(date).getFullYear(),
    project_id: project,
    campaign_id: camp,
    phase_id: phase,
    activity: activity,
    hours: hours,
    id_task: idTask
  });
  console.log("datos agregados");
  await task.save().then(resp => {
    //   console.log("Todo perfecto");
    //   res.status(201).json({
    //     message: "Task created"
    //   });
    return "Task created";
  });
  await HistoricCtr.historyData2(task.id);
}

function index(req, res) {
  Task.belongsTo(Phase, { foreignKey: "phase_id" });
  Task.belongsTo(Project, { foreignKey: "project_id" });
  Task.belongsTo(Campaign, { foreignKey: "campaign_id" });

  console.log("listando los tags del usuario");
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
  });
  Task.findAll({
    where: {
      user_id: req.params.userId
    },
    include: [
      {
        model: Phase,
        required: false
      },
      {
        model: Project
      },
      {
        model: Campaign
      }
    ]
  }).then(data => {
    res.json({
      data: data
    });
  });
}

async function getTaskFilterDate(req, res) {
  console.log("trayendo las tareas con filtro de fecha");
  let messageResponse = "";
  try {
    let query =
      "select t.id as user_id,ph.id as phase_id,c.id as campaign_id, p.id as project_id,t.year as year,t.month as month,t.day as day, t.hours as hours, t.activity as acti, t.id as task_id,t.date as date,p.name as project_name,c.name as camp_name,ph.name as phase_name from Tasks t inner join Projects p on p.id = t.project_id inner join Campaigns c on c.id = t.`campaign_id` inner join `Phases` ph on ph.id = t.phase_id where t.user_id =" +
      req.params.userId +
      ' and t.date ="' +
      req.body.date +
      '"';
    const resp = await sequelize.query(query);
    let response = [];
    let hours = 0;
    for (let i = 0; i < resp[0].length; i++) {
      let project = {
        name: resp[0][i].project_name,
        id: resp[0][i].project_id
      };
      let campaign = {
        name: resp[0][i].camp_name,
        id: resp[0][i].campaign_id
      };
      let phase = {
        name: resp[0][i].phase_name,
        id: resp[0][i].phase_id
      };
      response[i] = {
        Project: project,
        Campaign: campaign,
        Phase: phase,
        date: resp[0][i].date,
        id_task: resp[0][i].task_id,
        activity: resp[0][i].acti,
        hours: resp[0][i].hours,
        day: resp[0][i].day,
        month: resp[0][i].month,
        year: resp[0][i].year,
        project_id: resp[0][i].project_id,
        campaign_id: resp[0][i].campaign_id,
        phase_id: resp[0][i].phase_id,
        user_id: resp[0][i].user_id,
        id: resp[0][i].task_id
      };
      hours += resp[0][i].hours;
    }
    console.log(response);
    return res.status(200).json({
      code: 0,
      message: response,
      hours: hours
    });
  } catch (err) {
    messageResponse = "Ocurrió un error inesperado al traer los datos";
    console.log(messageResponse + ": " + err);
    return res.status(500).json({
      code: 1,
      message: messageResponse
    });
  }
}

//Mostrar usuairo por id
function show(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
  });
  if (!req.body.id) {
    res.status(400).json({
      message: "The task id is required"
    });
  }
  Task.findAll({ where: { id: req.params.id } }).then(resp => {
    res.json({
      data: resp
    });
  });
}
//Actualizar usuario
function update(req, res) {
  console.log("entro a editar la tarea");
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
  });
  try {
    console.log("task id" + req.params.id);
    Task.findOne({
      where: {
        id: req.params.id
      }
    }).then(task => {
      idTask = null;
      if (
        req.body.idTask != null &&
        req.body.idTask != undefined &&
        req.body.idTask != ""
      ) {
        idTask = req.body.idTask;
      }
      task.update(
          {
            user_id: req.body.userId,
            date: req.body.date,
            day: new Date(req.body.date).getDate(),
            month: new Date(req.body.date).getMonth() + 1,
            year: new Date(req.body.date).getFullYear(),
            project_id: req.body.project,
            campaign_id: req.body.campaign,
            phase_id: req.body.phase,
            activity: req.body.activity,
            hours: req.body.hours,
            id_task: idTask
          },
          {
            where: {
              id: req.params.id
            }
          }
        )
        .then(async update => {
          await HistoricCtr.updateHistoric(task.id);

          console.log("ok: " + update);
          res.json({
            message: "Task has been updated"
          });
        });
    });
  } catch (error) {
    console.log(errror);
  }
}
//Función para mostrar el cumplimiento de horas
function fulfilment(req, res) {
  console.log("***sacando las horas faltantes del mes***");
  try {
    User.findAll({
      where: {
        id: req.params.userId
      }
    }).then(user => {
      if (!user) {
        return res.status(500).json({
          message: "user not found"
        });
      }
      var month = null;
      var year = null;
      if (!req.body.month) {
        month = new Date().getMonth() + 1;
      } else {
        month = req.body.month;
      }
      if (!req.body.year) {
        year = new Date().getFullYear();
      } else {
        year = req.body.year;
      }
      console.log("++++++++++++++++++        " + year);
      Task.findAll({
        attributes: [[sequelize.fn("SUM", sequelize.col("hours")), "sum"]],
        where: {
          month: month,
          year: year,
          user_id: req.params.userId
        }
      }).then(sum => {
        if (sum.length < 1) {
          return res.status(400).json({
            sum: 0
          });
        }
        console.log("Esta es la suma" + JSON.stringify(sum[0]));
        var suma = JSON.parse(JSON.stringify(sum[0])).sum;
        var suma1 = parseFloat(suma);
        HoursForMonth.findAll({
          where: {
            year: year,
            month: month
          }
        }).then(resp => {
          if (resp.length != 1) {
            return res.status(400).json({
              message: "Year and month not found"
            });
          }
          console.log(resp[0].hoursToComplete);
          let hour = resp[0].hoursToComplete;
          let fulfil = hour - suma1;
          res.json({
            totalHours: hour,
            sumHour: suma1,
            fulfilment: fulfil
          });
        });
      });
    });
  } catch (error) {
    console.log(error);
  }
}

function monthFulfil(req, res) {
  console.log("*** Usuaios que no han cumplido las horas requeridas al mes***");
  try {
    User.findAll({
      where: {
        id: req.params.userId
      }
    }).then(user => {
      if (!user) {
        return res.status(500).json({
          message: "user not found"
        });
      }
      var month = null;
      var year = null;
      if (!req.body.month) {
        month = new Date().getMonth() + 1;
      } else {
        month = req.body.month;
      }
      if (!req.body.year) {
        year = new Date().getFullYear();
      } else {
        year = req.body.year;
      }
      console.log("++++++++++++++++++        " + year);
      Task.findAll({
        attributes: [[sequelize.fn("SUM", sequelize.col("hours")), "sum"]],
        where: {
          month: month,
          year: year,
          user_id: req.params.userId
        }
      }).then(sum => {
        if (sum.length < 1) {
          return res.status(400).json({
            sum: 0
          });
        }
        console.log("Esta es la suma" + JSON.stringify(sum[0]));
        var suma = JSON.parse(JSON.stringify(sum[0])).sum;
        var suma1 = parseFloat(suma);
        HoursForMonth.findAll({
          where: {
            year: year,
            month: month
          }
        }).then(resp => {
          if (resp.length != 1) {
            return res.status(400).json({
              message: "Year and month not found"
            });
          }
          console.log(resp[0].hoursToComplete);
          let hour = resp[0].hoursToComplete;
          let fulfil = hour - suma1;
          res.json({
            totalHours: hour,
            sumHour: suma1,
            fulfilment: fulfil
          });
        });
      });
    });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  //destroy,
  update,
  fulfilment,
  show,
  index,
  store,
  fulfilment,
  monthFulfil,
  getTaskFilterDate
};
