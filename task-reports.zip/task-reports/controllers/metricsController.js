const path = require("path");
const Task = require(path.join(__dirname, "../models/Task"));
const User = require(path.join(__dirname, "../models/User"));
const MonthHours = require(path.join(__dirname, "../models/MonthHours"));
const mongo = require("mongodb");

//método para traer los desarrolladores que no cumplen con las horas o que, se sobreejecutan
function hourControl(req, res ){
  const u_id = new mongo.ObjectID(req.params.userId)
  User.find({
    _id: u_id
  }).then(user =>{
    if(user.length != 1){
      return res.status(500).json({
        message: "User not found"
      })
    }
    var rol = user[0].rol
    if(user[0].rol != "admin"){
      return res.status(500).json({
        message: "Does not have permissions"
      })
    }
    Task.find({

    }).then(task => {
      if(!task){
        return res.status(400).json({
          message: "Task not found"
        })
      }
      for (let i = 0; i < task.length; i++) {
          console.log(task[9].created_at.getDate())

      }
      
    })
  })

}

//Método para traer top 5 de los proyectos con mayor cantidad de tiempo 

module.exports = {
  hourControl
};
