const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const CampaignPhaseUser = require("../models/campaignphaseuser")(
  sequelize,
  DataTypes
);
const Campaign = require("../models/campaign")(sequelize, DataTypes);
const Phase = require("../models/phase")(sequelize, DataTypes);
const Project = require("../models/project")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const Client = require("../models/client")(sequelize, DataTypes);

function store(req, res) {
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    //console.log(user[0].id)
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      return res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    console.log("Entró al método");
    for (let i = 0; i < req.body.campaign_id.length; i++) {
      let totalCost = req.body.total_cost / req.body.campaign_id.length;
      let estimateHours = req.body.estimated_hours / req.body.campaign_id.length;
      const campaignPhaseUser = CampaignPhaseUser.build({
        campaign_id: req.body.campaign_id[i],
        phase_id: req.body.phase_id,
        user_id: req.body.user_id,
        project_id: req.body.project_id,
        start_date: req.body.start_date,
        delivery_date: req.body.delivery_date,
        estimated_hours: estimateHours,
        part_rate: req.body.part_rate,
        total_cost: totalCost,
        gross_cost: req.body.gross_cost
      });
      campaignPhaseUser.save().then(resp => {
        res.status(201).json({
          message: "Profile has been created succesfully"
        });
      });
    }
  } catch (error) {
    console.log(error);
  }
}

function index(req, res) {
  console.log("Método de usuario fase campaña");
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  // Campaign.hasMany(CampaignPhaseUser, { foreignKey: "campaign_id" });
  CampaignPhaseUser.belongsTo(Campaign, { foreignKey: "campaign_id" });
  // Phase.hasMany(CampaignPhaseUser, { foreignKey: "phase_id" });
  CampaignPhaseUser.belongsTo(Phase, { foreignKey: "phase_id" });
  // Project.hasMany(CampaignPhaseUser, { foreignKey: "project_id" });
  // CampaignPhaseUser.belongsTo(Project, { foreignKey: "project_id" });
  // User.hasMany(CampaignPhaseUser, { foreignKey: "user_id" });
  CampaignPhaseUser.belongsTo(User, { foreignKey: "user_id" });
  //CampaignPhaseUser.belongsToMany(UnCliPro, { as: 'UnCliPro', through: 'Clients' })
  CampaignPhaseUser.findAll({
    include: [
      {
        model: Campaign,
        atrributes: ["name"],
        required: true
      },
      {
        model: Phase,
        attributes: ["name"],
        required: true
      },
      {
        model: User,
        attributes: ["name"],
        required: true
      }
    ],
    where: {
      project_id: req.params.id,
      status_id: 1
    }
  }).then(data => {
    res.json({
      data: data
    });
  });
}
//Mostrar usuairo por id
function show(req, res) {
  User.findAll({
    id: req.params.userId
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  CampaignPhaseUser.findAll({
    where: {
      id: req.params.id
    }
  }).then(resp => {
    res.json({
      data: resp
    });
  });
}

//Mostrar campañas del proyecto
function projectCampaign(req, res) {
  console.log("Método para consultar proyecto y campañas ");
  User.findAll({
    id: req.params.userId
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });

  Campaign.belongsTo(Client, { foreignKey: "client_id" });
  Campaign.findAll({
    where: {
      status_id : 1,
      project_id: req.params.id
    },
    include: [
      {
        model: Client,
        atrributes: ["name"],
        required: true,
      }
    ]
  }).then(resp => {
    console.log();
    res.json({
      data: resp
    });
  });
}

//Actualizar usuario
function update(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    CampaignPhaseUser.update(
      {
        campaign_id: req.body.campaign_id,
        phase_id: req.body.phase_id,
        user_id: req.body.user_id,
        project_id: req.body.project_id,
        start_date: req.body.start_date,
        delivery_date: req.body.delivery_date,
        real_date: req.body.real_date,
        estimated_hours: req.body.estimated_hours,
        part_rate: req.body.part_rate,
        total_cost: req.body.total_cost,
        gross_cost: req.body.gross_cost
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update => {
      res.json({
        message: "Rol has been updated"
      });
    });
  } catch (error) {
    console.log(errror);
  }
}
//Eliminar usuario
function destroy(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  CampaignPhaseUser.destroy({
    where: {
      id: req.params.id
    }
  });
}

function changeStatus(req, res) {
  try {
    CampaignPhaseUser.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado la camapaña fase usuario");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar la camapaña fase usuario",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  projectCampaign,
  changeStatus
};
