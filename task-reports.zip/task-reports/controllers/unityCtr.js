const bcrypt = require('bcrypt')
const path = require('path')
const jwt = require('jsonwebtoken')
var DataTypes = require('sequelize/lib/data-types');
var connection = require("../config/db");
var sequelize = require('../config/db.js')
const Unity = require('../models/unity')(sequelize, DataTypes)
const User = require('../models/user')(sequelize, DataTypes)


function store(req, res){
console.log('Método para registrar registrar unidad');
User.findAll({
  where: {
    id: req.params.id
  }
}).then(user =>{
  if(!user){
    return res.status(500).json({
      message: "user not found"
    })
  }else if(user[0].rol_id  != 1){
    return res.status(401).json({
      message: "Unauthorized"
    })
  }
})
  try {
    console.log('Entró al método')
    const unity = Unity.build({
      name:req.body.name,
      description: req.body.description
    });
    unity.save().then(resp => {
      res.status(201).json({
        message: "Unit has been created succesfully"
      })
    });
  } catch (error) {
    console.log(error)
  }
}

function index (req, res) {
  console.log('Método para listar  unidad');
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Unity.findAll({
    attributes: [['id','key'], 'name', 'description'],
    where:{
      status_id: 1
    }
  }).then(data=>{
    console.log(data)
    res.json({
      data:data
    })
  })
}
//Mostrar usuairo por id
function show (req, res) {
  User.findAll({
    where:{
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Unity.findAll({where: {id: req.params.id} }).then(resp=>{
    res.json({
      data: resp
    })
  })
}
//Actualizar usuario
function update (req, res) {
  User.findAll({
    where:{
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  try {
    console.log(req.body)
    Unity.update(
      {
       name:req.body.name,
       description: req.body.description
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update =>{
      res.json({
        message:"Rol has been updated"
      })
    })
  } catch (error) {
    console.log(errror)
  }
}
//Eliminar usuario
function destroy (req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user =>{
    if(!user){
      return res.status(500).json({
        message: "user not found"
      })
    }else if(user[0].rol_id  != 1){
      res.status(401).json({
        message: "Unauthorized"
      })
    }
  })
  Unity.destroy({
    where: {
      id:req.params.id
    }
  })
}
function changeStatus(req, res) {
  console.log('Método para eliminar unidad de negocio ' +req.params.id);
  try {
    Unity.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado de la unidad");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar la unidad",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}
module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  changeStatus
}