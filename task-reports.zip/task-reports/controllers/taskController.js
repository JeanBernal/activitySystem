const path = require("path");
const Task = require(path.join(__dirname, "../models/Task"));
const User = require(path.join(__dirname, "../models/User"));
const MonthHours = require(path.join(__dirname, "../models/MonthHours"));
const mongo = require("mongodb");

function store(req, res) {
  console.log("Registrar tareas");
  console.log(req.body);
  const o_id = new mongo.ObjectID(req.body.userId);
  User.find({
    _id: o_id
  }).then(user => {
    console.log(user);
    if (user.length != 1) {
      return res.status(500).json({
        message: "User not found"
      });
    }
    console.log("Crear tarea");
    Task.find({
      activity: req.body.activity
    }).then(task => {
      if (task.length >= 1) {
        return res.status(500).json({
          message: "Already registered task"
        });
      } else {
        const task = new Task({
          user: req.body.userId,
          date: req.body.date,
          project: req.body.project,
          sub_category: req.body.sunCategory,
          phase: req.body.phase,
          activity: req.body.activity,
          id_task: req.body.idTask,
          hours: parseFloat(req.body.hours)
        });
        task.save().then(task => {
          res
            .status(201)
            .json({
              message: "task created succesfully"
            })
            .catch(err => {
              res.status(500).json({
                error: err
              });
            });
        });
      }
    });
  });
}

function index(req, res) {
  const o_id = new mongo.ObjectID(req.params.userId);
  console.log(req.params.userId);
  let inDate = req.body.inDate;
  let finDate = req.body.finDate;
  User.find({
    _id: o_id
  }).then(user => {
    if (user.length != 1) {
      res.status(500).json({
        message: "User not found"
      });
    }
    Task.find(
      {
        $and: [
          { date: { $gte: inDate } }, 
          { date: { $lte: finDate } }
          // {$sort: {date:-1}}
        ]
      },
      (err, task) => {
        if (err) {
          console.log(err);
          return res.status(500).json({
            err: err
          });
        }
        if (!task) {
          return res.status(400).json({
            message: "tasks are not found in the requested range"
          });
        }
        res.json({
          data: task
        });
      }
    ).sort({date:-1});
  });
}

function update(req, res) {
  console.log("Actulizar tarea");
  try {
    const toUpdate = {
      user: req.body.user,
      date: req.body.date,
      project: req.body.project,
      sub_category: req.body.sub_category,
      phase: req.body.phase,
      activity: req.body.activity,
      id_task: req.body.id_task,
      hours: req.body.hours
    };
    console.log(toUpdate);

    Task.updateOne({ _id: req.params.id }, toUpdate, (err, data) => {
      res.json({ message: "Task updated" });
    });
  } catch (error) {
    console.log(error)
  }
}

function list(req, res) {
  try {
    const u_id = new mongo.ObjectID(req.params.userId);
    console.log(u_id);
    User.find({
      _id: u_id
    }).then(user => {
      if (user.length != 1) {
        return res.status(500).json({
          message: "User not found"
        });
      }
      Task.find({
        user:req.params.userId
      }).sort({date: -1}).then(task =>{
        if(!task){
          return res.status(400).json({
            message: "Tasks not found"
          });
        }
        res.json({
          data: task
        });
      });
    });
  } catch (error) {
    console.log(error);
  }
}
function fulfilment(req, res) {
  try {
    const u_id = new mongo.ObjectID(req.params.userId);
    var sum = null;
    User.find({
      _id: u_id
    }).then(user => {
      if (user.length != 1) {
        return res.status(500).json({
          mmesage: "User not found"
        });
      }
      Task.aggregate([
        {
          $match: { user: req.params.userId }
        },
        {
          $group: {
            _id: null,
            sum: { $sum: "$hours" }
          }
        }
      ]).then(sum => {
        if(sum.length != 1){
          return res.status(400).json({
            sum: 0
          })
        }
        sum = sum[0].sum;
        console.log(sum);
        MonthHours.find({
          $and: [
            { year: new Date().getFullYear() },
            { month: new Date().getMonth() + 1 }
          ]
        }).then(resp => {
          if (resp.length != 1) {
            return res.status(400).json({
              message: "Year and month not found"
            });
          }
          console.log(resp[0].hours);
          let hour = resp[0].hours;
          let fulfil = hour - sum;
          res.json({
            totalHours: hour,
            sumHour: sum,
            fulfilment: fulfil
          });
        });
      });
    });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  store,
  index,
  update,
  list,
  fulfilment
};
