const path = require("path");
const Project = require(path.join(__dirname, "../models/Project"));
const User = require(path.join(__dirname, "../models/User"));
const mongo = require("mongodb");

function store(req, res) {
  console.log(req.body);
  try {
    Project.find({where:{
      project_name: req.body.projectName
    }}).then(project => {
      if (project.project_name >= 1) {
        return res.status(409).json({
          message: "Already reegistered project"
        });
      } else {
        const project = new Project({
            user: req.body.user,
            project_name: req.body.nameProject,
            holding_company: req.body.businessHolding,
            unit: req.body.unit,
            client: req.body.client,
            nit: req.body.nit,
            category: req.body.category,
            sub_category: req.body.listCategory,
            objective_project: req.body.objectivesProject,
            use_type: req.body.typeUse,
            intellectual_property: req.body.intellectualProperty,
            licensed: req.body.licensed,
            finality: req.body.purpose,
            monthly_fee: req.body.feeMonthly,
            monthly_fee_cost: req.body.costFeeMonthly,
            cost_center: req.body.costCenter,
            start_date: req.body.startDate,
            estimated_delivery_date: req.body.stimateDate,
            real_delivery_date: req.body.realDate,
            estimated_hours_disigning: req.body.timeDesign,
            estimated_hours_coding: req.body.timeCode,
            estimated_hours_production: req.body.timeProduction,
            estimated_hours_investigation: req.body.timeInvestigation,
            estimated_hours_prube: req.body.timeTests,
            estimated_hours_maintenance: req.body.timeMaintenance,
            updates: req.body.update,
            estimated_hours_updates: req.body.timeUpdate,
            assigned_developers: req.body.numberDevelopers
        });
        project
          .save()
          .then(project => {
            console.log('**************')
            console.log(project);
            res.status(201).json({
              message: "project created successfully",
            });
          })
          .catch(err => {
            res.status(500).json({
              error: err
            });
          });
      }
    });
  } catch (error) {
    res.send().json({
      error: error
    });
    console.log(error);
  }
}
function index(req, res) {
    console.log("Listar proyectos")
    Project.find({}, (err, projects) => {
      res.json({
        data: projects
      });
    }).sort({created_at: -1});
}

function update(req, res) {
  console.log("Actulizar proyecto");

  const toUpdate = {
    user: req.body.user,
    project_name: req.body.nameProject,
    holding_company: req.body.businessHolding,
    unit: req.body.unit,
    client: req.body.client,
    nit: req.body.nit,
    category: req.body.category,
    sub_category: req.body.listCategory,
    objective_project: req.body.objectivesProject,
    use_type: req.body.typeUse,
    intellectual_property: req.body.intellectualProperty,
    licensed: req.body.licensed,
    finality: req.body.purpose,
    monthly_fee: req.body.feeMonthly,
    monthly_fee_cost: req.body.costFeeMonthly,
    cost_center: req.body.costCenter,
    start_date: req.body.startDate,
    estimated_delivery_date: req.body.stimateDate,
    real_delivery_date: req.body.realDate,
    estimated_hours_disigning: req.body.timeDesign,
    estimated_hours_coding: req.body.timeCode,
    estimated_hours_production: req.body.timeProduction,
    estimated_hours_investigation: req.body.timeInvestigation,
    estimated_hours_prube: req.body.timeTests,
    estimated_hours_maintenance: req.body.timeMaintenance,
    updates: req.body.updates,
    estimated_hours_updates: req.body.timeUpdate,
    assigned_developers: req.body.numberDevelopers
  };

  Project.updateOne({ _id: req.params.id }, toUpdate, (err, data) => {
    res.json({ message: "Project Updated" });
  });
}


module.exports = {
  store,
  index,
  update
};