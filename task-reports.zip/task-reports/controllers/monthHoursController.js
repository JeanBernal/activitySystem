const path = require("path");
const MonthHours = require(path.join(__dirname, "../models/MonthHours"));
const User = require(path.join(__dirname, "../models/User"));
const mongo = require("mongodb");

function store(req, res) {
  try {
    const data = new MonthHours({
      year: req.body.year,
      month: req.body.month,
      hours: req.body.hours
    });
    data
      .save()
      .then(monthHours => {
        res.status(201).json({
          message: "Hours of month created"
        });
      })
      .catch(err => {
        res.status(500).json({
          error: err
        });
      });
  } catch (error) {
    console.log(error);
  }
}

function index(req, res) {
  try {
    const u_id = new mongo.ObjectID(req.params.userId);
    console.log(u_id);
    MonthHours.find({}).then(monthHours => {
      console.log(monthHours);
      if (!monthHours) {
        return res.status(400).json({
          message: "No se encontraron resultados"
        });
      }
      res.json({
        data: monthHours
      });
    });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  store,
  index
};
