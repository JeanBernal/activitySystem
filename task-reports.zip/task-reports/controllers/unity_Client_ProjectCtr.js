const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const UnCliPro = require("../models/unity_client_project")(
  sequelize,
  DataTypes
);
const Client = require("../models/client")(sequelize, DataTypes);
const Unity = require("../models/unity")(sequelize, DataTypes);
const Project = require("../models/project")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);

function store(req, res) {
  console.log("Metodo de guardar");
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      return res.status(401).json({
        message: "Unauthorized"
      });
    }
  });

  UnCliPro.findAll({
    where: {
      unity_id: req.body.unity_id,
      client_id: req.body.client_id,
      project_id: req.body.project_id,
      status_id: 1
    }
  })
    .then(unCliPro => {
      console.log("**********************");
      console.log(unCliPro.length);
      if (unCliPro.length > 0) {
         res.status(500).json({
          message: "La unidad cliente ya se encuentra registrada para este proyecto"
        });
      } else {
        console.log("Va ha registrar unidad cliente");
        const unCliPro = UnCliPro.build({
          unity_id: req.body.unity_id,
          client_id: req.body.client_id,
          project_id: req.body.project_id
        });
        unCliPro.save().then(resp => {
          res.status(201).json({
            data: resp[0]
          });
        });
      }
    })
    .catch(error => {
      console.log(error)
    });
}

function index(req, res) {
  console.log("************ index **********");
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  if (!req.params.id) {
    res.status(400).json({
      message: "The project id is required"
    });
  }

  // Client.hasMany(UnCliPro, { foreignKey: "client_id" });
  // Unity.hasMany(UnCliPro,{foreignKey: "unity_id"});

  // Client.hasMany(UnCliPro, { foreignKey: "client_id" });
  UnCliPro.belongsTo(Client, { foreignKey: "client_id" });
  // Unity.hasMany(UnCliPro, { foreignKey: "unity_id" });
  UnCliPro.belongsTo(Unity, { foreignKey: "unity_id" });
  // Project.hasMany(UnCliPro, { foreignKey: "project_id" });
  // UnCliPro.belongsTo(Project, { foreignKey: "id" });
  //UnCliPro.belongsToMany(UnCliPro, { as: 'UnCliPro', through: 'Clients' })
  console.log("************ Consultando **********");
  UnCliPro.findAll({
    include: [
      {
        model: Client,
        attributes: ["name"],
        required: true
      },
      {
        model: Unity,
        attributes: ["name", "id"],
        required: true
      }
    ],
    where: {
      project_id: req.params.id,
      status_id: 1
    }
  })
    .then(data => {
      console.log("Lo que trae: " + JSON.stringify(data));
      res.json({
        data: data
      });
    });
}
//Mostrar
function show(req, res) {
  try {
    User.findAll({
      where: {
        id: req.params.userId
      }
    }).then(user => {
      if (!user) {
        return res.status(500).json({
          message: "user not found"
        });
      } else if (user[0].rol_id != 1) {
        res.status(401).json({
          message: "Unauthorized"
        });
      }
    });
    console.log("llega aqui");
    UnCliPro.findAll({ where: { id: req.params.id } }).then(resp => {
      res.json({
        data: resp
      });
    });
  } catch (error) {
    console.log(error);
  }
}
//Actualizar usuario
function update(req, res) {
  console.log("metodo para actualizar");
  User.findAll({
    id: req.params.userId
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    UnCliPro.update(
      {
        unity_id: req.body.unity_id,
        client_id: req.body.client_id,
        project_id: req.body.project_id
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update => {
      res.json({
        message: "Rol has been updated"
      });
    });
  } catch (error) {
    console.log(errror);
  }
}
//Eliminar usuario
function destroy(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  UnCliPro.destroy({
    where: {
      id: req.params.id
    }
  });
}

function changeStatus(req, res) {
  try {
    UnCliPro.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado de unidad cliente proyecto");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar unidad cliente proyecto",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  changeStatus
};
