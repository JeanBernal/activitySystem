const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const Task = require("../models/task")(sequelize, DataTypes);
const CampaignPhaseUser = require("../models/campaignphaseuser")(sequelize, DataTypes);
const Campaign = require("../models/campaign")(sequelize, DataTypes);
const Phase = require("../models/phase")(sequelize, DataTypes);
const Project = require("../models/project")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const Client = require("../models/client")(sequelize, DataTypes);
const Unity = require("../models/unity")(sequelize, DataTypes);
const UCP = require("../models/unity_client_project")(sequelize, DataTypes);
const Detail = require("../models/detail")(sequelize, DataTypes);
const Historic = require("../models/historic")(sequelize, DataTypes);
const dateFormat = require("dateformat");
const Op = sequelize.Op;
let cont_error = 0;

function historicQuery(req, res) {
    console.log("Consulta para alimentar tabla histórico")
    try {
        Task.belongsTo(Campaign, { foreignKey: "campaign_id" });
        Task.belongsTo(Project, { foreignKey: "project_id" });
        Task.belongsTo(User, { foreignKey: "user_id" });
        Campaign.hasOne(CampaignPhaseUser, { foreignKey: "id" });
        Task.belongsTo(Phase, { foreignKey: "phase_id" });

        Task.findAll({
            atrributes: ['id', 'activity', 'hours', 'date'],
            include: [{
                    model: Campaign,
                    atrributes: ['id', 'name'],
                    required: false,
                    include: {

                        model: CampaignPhaseUser,
                        attributes: ['estimated_hours', 'total_cost', 'gross_cost'],
                        distinct: true,
                        required: false
                    },
                },
                {
                    model: Project,
                    attributes: ['id', 'name'],
                    required: false,
                },
                {
                    model: Phase,
                    attributes: ['id', 'name'],
                    required: false,
                },
                {
                    model: User,
                    attributes: ['id', 'name'],
                    required: false,
                }
            ]
        }).then(data => {
            // Project.findAll({

            // })
            for (let i = 0; i < data.length; i++) {
                task_id = data[i].id,
                    task_activity = data[i].activity,
                    task_hours = data[i].hours,
                    // task_date = data[i].date
                    // for (let j = 0; j < data.length; j++) {
                    //   project_id = data[i][j].project_id,
                    //   campaign_id = data[i][j].campaign_id,
                    //   phase_id           
                    // }

                    console.log(b)

            }
            res.json({
                data: data
            });
        });
    } catch (error) {
        console.log(error)
    }
}

async function historyData2(task_id) {
    console.log('********************+Agregando datos a la base********************************');
    const resp = await sequelize.query('select u.id as user_id,p.id as project_id,c.id as camp_id, t.id as task_id, p.name as project_name, c.name as camp_name,t.activity as task_name, t.day as task_day, t.month as task_month, t.year as task_year, ph.name as phase,u.name as user_name,t.hours as horas,t.date as date,c.client_id as client_id from Tasks t inner join Campaigns c on c.id = t.campaign_id inner join Projects p on p.id = t.project_id inner join Phases ph on ph.id = t.phase_id inner join Users u on u.id = t.user_id where t.id = ' + task_id);
    let sum = 0;
    for (let i = 0; i < resp[0].length; i++) {
        console.log('sacando la información en la posición: ' + i);
        let clientId = resp[0][i].client_id;
        let projectId = resp[0][i].project_id;
        let user_id = resp[0][i].user_id;
        //let date = dateFormat(new Date(resp[0][i].date), "yyyy-mm-dd h:MM:ss")
        let date = resp[0][i].date
        sum += resp[0][i].horas;
        if (user_id != null || user_id != undefined) {
            let user = await getUserInfo(user_id);
            resp[0][i].user = user;
        }
        if (clientId != null || clientId != undefined) {
            let client = await getClientInfo(clientId);
            resp[0][i].client = client;
            if (projectId != null || projectId != undefined) {
                let unity = await getUnityInfo(projectId, clientId);
                resp[0][i].unity = unity;
            }
        }
        
        let sumaParse = await distribution();
        
        const historic = Historic.build({
            project_id: resp[0][i].project_id,
            project_name: resp[0][i].project_name,
            unity_id: resp[0][i].unity.id,
            unity_name: resp[0][i].unity.name,
            client_id: resp[0][i].client.id,
            client_name: resp[0][i].client.name,
            campaign_id: resp[0][i].camp_id,
            campaign_name: resp[0][i].camp_name,
            user_id: resp[0][i].user_id,
            user_name: resp[0][i].user_name,
            user_salary: resp[0][i].user.total_salary,
            task_id: resp[0][i].task_id,
            task_activity: resp[0][i].task_name,
            task_hours: resp[0][i].horas,
            task_date: date,
            task_day: resp[0][i].task_day,
            task_month: resp[0][i].task_month,
            task_year: resp[0][i].task_year,
            user_cost: resp[0][i].user.total_salary/30/8 * (resp[0][i].horas),
            phase_name: resp[0][i].phase,
            hoursDistribution: resp[0][i].horas / sumaParse
        });
        await historic.save().then(history => {
            console.log('Se agregó exitosamente');
        }).catch(err => {
            console.log('Salió un error no controlado');
        })
    }
    console.log('****************horas: ' + sum);
    return 'ok';
}

 async function distribution(res){
    return Task.findAll({
        attributes: [[sequelize.fn("SUM", sequelize.col("hours")), "sum"]]
      }).then(sum => {
        console.log("Esta es la suma" + JSON.stringify(sum[0]));
        var suma = JSON.parse(JSON.stringify(sum[0])).sum;
        var sumaParse = parseFloat(suma);
        return sumaParse;
      })
}

async function historyData(req, res) {
    
    console.log('Agregando datos a la base');
    const resp = await sequelize.query('select u.id as user_id,p.id as project_id,c.id as camp_id, t.id as task_id, p.name as project_name, c.name as camp_name,t.activity as task_name, t.day as task_day, t.month as task_month, t.year as task_year, ph.name as phase,u.name as user_name,t.hours as horas,t.date as date,c.client_id as client_id from Tasks t inner join Campaigns c on c.id = t.campaign_id inner join Projects p on p.id = t.project_id inner join Phases ph on ph.id = t.phase_id inner join Users u on u.id = t.user_id');
    // let sum = 0;
    for (let i = 0; i < resp[0].length; i++) {
        let response = await process(resp[0][i]);
    }
    return res.status(200).json({
        message: resp
    });
}

async function process(resp) {
    console.log('sacando la información');
        let clientId = resp.client_id;
        let projectId = resp.project_id;
        let user_id = resp.user_id;
        //let date = dateFormat(new Date(resp.date), "yyyy-mm-dd h:MM:ss")
        let date = resp.date

        if (user_id != null || user_id != undefined) {
            let user = await getUserInfo(user_id);
            resp.user = user;
        }
        if (clientId != null || clientId != undefined) {
            let client = await getClientInfo(clientId);
            resp.client = client;
            if (projectId != null || projectId != undefined) {
                let unity = await getUnityInfo(projectId, clientId);
                resp.unity = unity;
            }
        }

        let sumaParse = await distribution();
        console.log('hours = ' + resp.horas/sumaParse);
        let historic = null;
        if(resp.unity == '0'){
            historic = Historic.build({
                project_id: resp.project_id,
                project_name: resp.project_name,
                // unity_id: resp.unity.id,
                // unity_name: resp.unity.name,
                client_id: resp.client.id,
                client_name: resp.client.name,
                campaign_id: resp.camp_id,
                campaign_name: resp.camp_name,
                user_id: resp.user_id,
                user_name: resp.user_name,
                user_salary: resp.user.total_salary,
                task_id: resp.task_id,
                task_activity: resp.task_name,
                task_hours: resp.horas,
                task_date: date,
                task_day: resp.task_day,
                task_month: resp.task_month,
                task_year: resp.task_year,
                user_cost: resp.user.total_salary/30/8 * (resp.horas),
                phase_name: resp.phase,
                hoursDistribution: resp.horas / sumaParse
            });
        }else{
            historic = Historic.build({
                project_id: resp.project_id,
                project_name: resp.project_name,
                unity_id: resp.unity.id,
                unity_name: resp.unity.name,
                client_id: resp.client.id,
                client_name: resp.client.name,
                campaign_id: resp.camp_id,
                campaign_name: resp.camp_name,
                user_id: resp.user_id,
                user_name: resp.user_name,
                user_salary: resp.user.total_salary,
                task_id: resp.task_id,
                task_activity: resp.task_name,
                task_hours: resp.horas,
                task_date: date,
                task_day: resp.task_day,
                task_month: resp.task_month,
                task_year: resp.task_year,
                user_cost: resp.user.total_salary/30/8 * (resp.horas),
                phase_name: resp.phase,
                hoursDistribution: resp.horas / sumaParse
            });
        }
        
        await historic.save().then(history => {
            console.log('Se agregó exitosamente');
        }).catch(err => {
            console.log('Salió un error no controlado: ' + err);
        })
}

async function updateHistoric(task_id) {
    console.log('******************** Agregando datos a la base ********************************');
    const resp = await sequelize.query('select u.id as user_id,p.id as project_id,c.id as camp_id, t.id as task_id, p.name as project_name, c.name as camp_name,t.activity as task_name, t.day as task_day, t.month as task_month, t.year as task_year, ph.name as phase,u.name as user_name,t.hours as horas,t.date as date,c.client_id as client_id from Tasks t inner join Campaigns c on c.id = t.campaign_id inner join Projects p on p.id = t.project_id inner join Phases ph on ph.id = t.phase_id inner join Users u on u.id = t.user_id where t.id = ' + task_id);
    let sum = 0;
    for (let i = 0; i < resp[0].length; i++) {
        console.log('sacando la información en la posición: ' + i);
        let clientId = resp[0][i].client_id;
        let projectId = resp[0][i].project_id;
        let user_id = resp[0][i].user_id;
        //let date = dateFormat(new Date(resp[0][i].date), "yyyy-mm-dd h:MM:ss")
        let date = resp[0][i].date
        sum += resp[0][i].horas;
        if (user_id != null || user_id != undefined) {
            let user = await getUserInfo(user_id);
            resp[0][i].user = user;
        }
        if (clientId != null || clientId != undefined) {
            let client = await getClientInfo(clientId);
            resp[0][i].client = client;
            if (projectId != null || projectId != undefined) {
                let unity = await getUnityInfo(projectId, clientId);
                resp[0][i].unity = unity;
            }
        }

        let sumaParse = await distribution();
        
        Historic.update({
            project_id: resp[0][i].project_id,
            project_name: resp[0][i].project_name,
            unity_id: resp[0][i].unity.id,
            unity_name: resp[0][i].unity.name,
            client_id: resp[0][i].client.id,
            client_name: resp[0][i].client.name,
            campaign_id: resp[0][i].camp_id,
            campaign_name: resp[0][i].camp_name,
            user_id: resp[0][i].user_id,
            user_name: resp[0][i].user_name,
            user_salary: resp[0][i].user.total_salary,
            task_id: resp[0][i].task_id,
            task_activity: resp[0][i].task_name,
            task_hours: resp[0][i].horas,
            task_date: date,
            task_day: resp[0][i].task_day,
            task_month: resp[0][i].task_month,
            task_year: resp[0][i].task_year,
            user_cost: resp[0][i].user.total_salary/30/8 * (resp[0][i].horas),
            phase_name: resp[0][i].phase,
            hoursDistribution: resp.horas / sumaParse
        },
        {
          where: {
              task_id: task_id
          }  
        })
        .then(update => {

            console.log("ok: " + update);
        })
        .catch(err => {
            console.log(err)
            console.log('Salió un error no controlado');
        })
    }
    console.log('****************horas: ' + sum);
    return 'ok';
}

async function updateData(req, res) {
    console.log('Agregando datos a la base');
    const resp = await sequelize.query('select u.id as user_id,p.id as project_id,c.id as camp_id, t.id as task_id, p.name as project_name, c.name as camp_name,t.activity as task_name, t.day as task_day, t.month as task_month, t.year as task_year, ph.name as phase,u.name as user_name,t.hours as horas,t.date as date,c.client_id as client_id from Tasks t inner join Campaigns c on c.id = t.campaign_id inner join Projects p on p.id = t.project_id inner join Phases ph on ph.id = t.phase_id inner join Users u on u.id = t.user_id');
    // let sum = 0;
    for (let i = 0; i < resp[0].length; i++) {
        let response = await updateProcess(resp[0][i]);
    }
    return res.status(200).json({
        message: resp
    });
}

async function updateProcess(resp) {
    console.log('sacando la información');
        let clientId = resp.client_id;
        let projectId = resp.project_id;
        let user_id = resp.user_id;
        //let date = dateFormat(new Date(resp.date), "yyyy-mm-dd h:MM:ss")
        let date = resp.date

        if (user_id != null || user_id != undefined) {
            let user = await getUserInfo(user_id);
            resp.user = user;
        }
        if (clientId != null || clientId != undefined) {
            let client = await getClientInfo(clientId);
            resp.client = client;
            if (projectId != null || projectId != undefined) {
                let unity = await getUnityInfo(projectId, clientId);
                resp.unity = unity;
            }
        }
        let unityId;
        let unityName;
        if(resp.unity == '0'){
            unityId = null
            unityName = null
        }else{
            unityId = resp[0][i].unity.id;
            unityName = resp[0][i].unity.name;
        }

        let sumaParse = await distribution();

        Historic.update({
            project_id: resp[0][i].project_id,
            project_name: resp[0][i].project_name,
            unity_id: unityId,
            unity_name: unityName,
            client_id: resp[0][i].client.id,
            client_name: resp[0][i].client.name,
            campaign_id: resp[0][i].camp_id,
            campaign_name: resp[0][i].camp_name,
            user_id: resp[0][i].user_id,
            user_name: resp[0][i].user_name,
            user_salary: resp[0][i].user.total_salary,
            task_id: resp[0][i].task_id,
            task_activity: resp[0][i].task_name,
            task_hours: resp[0][i].horas,
            task_date: date,
            task_day: resp[0][i].task_day,
            task_month: resp[0][i].task_month,
            task_year: resp[0][i].task_year,
            user_cost: resp[0][i].user.total_salary/30/8 * (resp[0][i].horas),
            phase_name: resp[0][i].phase,
            hoursDistribution: resp.horas / sumaParse
        },
        {
          where: {
              task_id: task_id
          }  
        })
        .then(update => {

            console.log("ok: " + update);
            res.json({
                message: "Historic has been updated"
            });
        })
        .catch(err => {
            console.log('Salió un error no controlado');
        })
}

function getUserInfo(id) {
    console.log('sacando información del usuario');
    return Detail.findOne({
        where: {
            user_id: id
        }
    }).then(user => {
        return user;
    })
}

function getClientInfo(id) {
    console.log('Sacando información del cliente');
    return Client.findOne({
        where: {
            id: id
        }
    }).then(client => {
        return client;
    })
}

function getUnityInfo(projectId, clientId) {
    console.log('Sacando información de la unidad');
    return UCP.findAll({
        where: {
            project_id: projectId,
            client_id: clientId
        }
    }).then(upc => {
        if(upc.length == 0){
            this.cont_error++;
            console.log(this.cont_error);
            return '0';
        }
        return Unity.findOne({
            where: {
                id: upc[0].unity_id
            }
        }).then(unity => {
            return unity;
        })
    })
}

async function getTaskInfo(req, res) {
    console.log('Trayendo información de las tareas');
    try {
        User.findAll({
            where: {
                id: req.params.userId
            }
        }).then(async users => {
            if (users.length == 0) {
                console.log('No tiene permiso para hacer esta operación');
                return res.status(401).json({
                    cod: 2,
                    message: 'No tiene permiso para hacer esta operación'
                });
            }
            if (users[0].rol_id != 1) {
                console.log('No tiene permiso para hacer esta operación');
                return res.status(401).json({
                    cod: 2,
                    message: 'No tiene permiso para hacer esta operación'
                });
            }
            let query = 'select * from Historics';

            let search = {};
            let cont = 0;
            if (req.body.projectId != '') {
                if (cont == 0) {
                    query += ' where';
                } else {
                    query += ' and';
                }
                cont = 1;
                query += ' project_id =' + req.body.projectId;
            }
            if (req.body.userId != '') {
                if (cont == 0) {
                    query += ' where';
                } else {
                    query += ' and';
                }
                cont = 1;
                query += ' user_id =' + req.body.userId;
            }
            console.log('la fecha: ' + req.body.date);
            if (req.body.date != '') {
                if (cont == 0) {
                    query += ' where';
                } else {
                    query += ' and';
                }
                cont = 1;
                query += ' task_date like \"%' + req.body.date + '%\"';
            }
            const resp = await sequelize.query(query);
            let sum = 0;
            for (let i = 0; i < resp[0].length; i++) {
                sum += resp[0][i].task_hours;
            }
            let response = {
                total_hours: sum,
                historic: resp[0]
            };
            return res.status(200).json({
                data: response
            });
        }).catch(err => {
            console.log('Salió un error inesperado al traer la información: ' + err);
            return res.status(500).json({
                cod: 1,
                message: 'Hubo un error inesperado al traer la información'
            });
        })
    } catch (err) {
        console.log('Hubo un error inesperado al traer la información: ' + err);
        return res.status(500).json({
            cod: 1,
            message: 'Hubo un error inesperado al traer la información'
        });
    }
}



module.exports = {
    historicQuery,
    historyData,
    historyData2,
    getTaskInfo,
    updateHistoric
}