const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const Project = require("../models/project")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const HoldingCompany = require("../models/holdingcompany")(
  sequelize,
  DataTypes
);
const CostCenter = require("../models/costcenter")(sequelize, DataTypes);

function store(req, res) {
  console.log(req.body);
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    //console.log(user[0].id)
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      return res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    console.log("Entró al método");
    const project = Project.build({
      user_id: req.body.user_id,
      cost_center_id: req.body.cost_center_id,
      name: req.body.name,
      holding_company_id: req.body.holding_company,
      nit: req.body.nit,
      category: req.body.category,
      objective_project: req.body.objective_project,
      use_type: req.body.use_type,
      intellectual_property: req.body.intellectual_property,
      licensed: req.body.licensed,
      finality: req.body.finality,
      monthly_fee: req.body.monthly_fee,
      monthly_fee_cost: req.body.monthly_fee_cost
    });
    project.save().then(resp => {
      res.status(201).json({
        message: "Profile has been created succesfully",
        data: resp
      });
    });
  } catch (error) {
    console.log(error);
  }
}

function index(req, res) {
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
    Project.belongsTo(HoldingCompany, { foreignKey: "holding_company_id" });
    Project.belongsTo(CostCenter, { foreignKey: "cost_center_id" });
    Project.findAll({
      attributes: [
        ["id", "key"],
        "name",
        "nit",
        "category",
        "objective_project",
        "use_type",
        "intellectual_property",
        "licensed",
        "finality",
        "monthly_fee",
        "monthly_fee_cost"
      ],
      where: {
        status_id: 1
      },
      include: [
        {
          model: HoldingCompany,
          required: false,
          attributes: [["name", "holding_company"], "id"]
        },
        {
          model: CostCenter,
          required: false,
          attributes: [["name", "cost_center"] , "id"]
        }
      ]
    })
      .then(data => {
        console.log(data);
        res.json({
          data: data
        });
        // })
      })
      .catch(err => {
        console.log(err);
      });
  });
}

function detailProject(req, res) {
  try {
    console.log(req.params.id);
    User.findAll({
      where: {
        id: req.params.userId
      }
    }).then(user => {
      if (!user) {
        return res.status(500).json({
          message: "user not found"
        });
      }
      Project.belongsTo(HoldingCompany, { foreignKey: "holding_company_id" });
      Project.belongsTo(CostCenter, { foreignKey: "cost_center_id" });
      Project.findAll({
        attributes: [
          ["id", "key"],
          "name",
          "nit",
          "category",
          "objective_project",
          "use_type",
          "intellectual_property",
          "licensed",
          "finality",
          "monthly_fee",
          "monthly_fee_cost"
        ],
        include: [
          {
            model: HoldingCompany,
            required: false,
            attributes: [["name", "holding_company"], "id"]
          },
          {
            model: CostCenter,
            required: false,
            attributes: [["name", "cost_center"], "id"]
          }
        ],
        where: {
          id: req.params.id
        }
      })
        .then(data => {
          console.log(data);
          res.json({
            data: data
          });
          // })
        })
        .catch(err => {
          console.log(err);
        });
    });
  } catch (error) {
    console.error(error);
  }
}

//Mostrar usuairo por id
function show(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
    // else if (user[0].rol_id != 1) {
    //   res.status(401).json({
    //     message: "Unauthorized"
    //   });
    // }
  });
  Project.findAll({ where: { id: req.params.id } }).then(resp => {
    res.json({
      data: resp
    });
  });
}
//Actualizar usuario
function update(req, res) {
  console.log('Actualizar proyecto');
  console.log(req.body);
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    Project.update(
      {
        user_id: req.body.user_id,
        cost_center_id: req.body.cost_center_id,
        name: req.body.name,
        holding_company_id: req.body.holding_company,
        nit: req.body.nit,
        category: req.body.category,
        objective_project: req.body.objective_project,
        use_type: req.body.use_type,
        intellectual_property: req.body.intellectual_property,
        licensed: req.body.licensed,
        finality: req.body.finality,
        monthly_fee: req.body.monthly_fee,
        monthly_fee_cost: req.body.monthly_fee_cost
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update => {
      res.json({
        message: "Rol has been updated"
      });
    });
  } catch (error) {
    console.log(errror);
  }
}
//Eliminar usuario
function destroy(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  Project.destroy({
    where: {
      id: req.params.id
    }
  });
}


function changeStatus(req, res) {
  console.log('Método para actualizar proyecto' + req.params.id)
  try {
    Project.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado del proyecto");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar el proyecto",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  detailProject,
  changeStatus
};
