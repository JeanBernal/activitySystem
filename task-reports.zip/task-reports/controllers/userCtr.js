const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
//const sequelize = require('sequelize')
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const User = require("../models/user")(sequelize, DataTypes);
const Detail = require("../models/detail")(sequelize, DataTypes);
const Profile = require("../models/profile")(sequelize, DataTypes);
const Rol = require("../models/rol")(sequelize, DataTypes);
const ContractType = require("../models/contracttype")(sequelize, DataTypes);

//const mongo = require("mongodb");
//const mailer = require(path.join(__dirname, '../controllers/mailerController'))

//Registro de usuario passport google
function store(req, res) {
    try {
        console.log("Entró");
        console.log(req.body);

        User.findAll({
            where: {
                email: req.body.email
            }
        }).then(user => {
            if (user.length > 0) {
                return res.status(500).json({
                    message: "The user is already registered"
                });
            }

            bcrypt.hash(req.body.password, 10, (err, hash) => {
                if (err) {
                    return res.status(500).json({
                        error: err
                    });
                } else {
                    const user = User.build({
                        name: req.body.name,
                        email: req.body.email,
                        password: hash,
                        rol_id: req.body.rol_id,
                        profile_id: req.body.profile_id
                    });
                    user
                        .save()
                        .then(data => {
                            console.log("user: " + req.body.totalSalary);
                            const detail = Detail.build({
                                user_id: data.id,
                                total_salary: req.body.totalSalary,
                                gross_salary: req.body.netSalary,
                                additional_cost: req.body.additionalCost,
                                date_admission: req.body.dateAdmission,
                                bussiness_unit: req.body.bussinessUnit,
                                contract_type_id: 7
                            });
                            console.log(detail);
                            detail
                                .save()
                                .then(detailData => {
                                    res.status(200).json({
                                        message: "User Created"
                                    });
                                })
                                .catch(err => {
                                    console.log(err);
                                    res.status(500).json({
                                        error: err
                                    });
                                });
                        })
                        .catch(err => {
                            console.log(err);
                            res.status(500).json({
                                error: err
                            });
                        });
                }
            });
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            error: err
        });
    }
}

//Listar usuarios
function index(req, res) {
    try {
        //Detail.hasMany(User, { foreignKey: "user_id" });
        User.hasOne(Detail, { foreignKey: "user_id" });
        User.belongsTo(Profile, { foreignKey: "profile_id" });
        User.belongsTo(Rol, { foreignKey: "rol_id" });
        Detail.belongsTo(ContractType, { foreignKey: "contract_type_id" });
        //User.belongsTo(Detail, { foreignKey: "id" });
        User.findAll({
            attributes: ["id", "profile_id", "name", "email", "status_id"],
            where: {
                status_id: 1
            },
            include: [{
                    model: Detail,
                    attributes: [
                        "total_salary",
                        "gross_salary",
                        "additional_cost",
                        "date_admission",
                        "business_unit"
                    ],
                    required: false,
                    include: [{
                        model: ContractType,
                        attributes: ["name", "id"],
                        required: true
                    }]
                },
                {
                    model: Profile,
                    attributes: ["name", "description", "salary_range"]
                },
                {
                    model: Rol,
                    attributes: ["rol_name", "id"]
                }
            ]
        }).then(data => {
            console.log("datos sacados de la base de datos: " + data);
            res.json({
                data: data
            });
        });
    } catch (error) {
        console.log(error);
    }
}
//Mostrar usuairo por id
function show(req, res) {
    if (req.params.id.length < 0) {
        res.status(400).json({
            message: "The user id is required"
        });
    }
    User.findAll({ id: req.params.id }).then(resp => {
        res.json({
            data: resp
        });
    });
}
//Actualizar usuario
function update(req, res) {
    console.log(req.body);
    try {
        if (req.params.id.length < 0) {
            res.status(500).json({
                message: "User not found"
            });
        }
        if (req.body.name.length < 0) {
            res.status(400).json({
                message: "The name is required"
            });
        }
        if (req.body.email.length < 0) {
            res.status(400).json({
                message: "The email is required"
            });
        }
        User.update({
                name: req.body.name,
                email: req.body.email,
                profile_id: req.body.profileId,
                rol_id: req.body.rolId
            }, {
                where: {
                    id: req.params.id
                }
            })
            .then(update => {
                console.log("Se actualizó");
            })
            .catch(error => {
                res.json({
                    message: "Hubo un error al actualizar el usuario",
                    error: error
                });
            });
        Detail.findAll({
                where: {
                    user_id: req.params.id
                }
            })
            .then(detail => {
                messageResponse = "";
                if (detail.length == 0) {
                    messageResponse = "No se encontró los detalles del usuario";
                    console.log(messageResponse);
                    detail = new Detail();
                    detail.total_salary = req.body.totalSalary;
                    detail.gross_salary = req.body.grossSalary;
                    detail.additional_cost = req.body.additionalCost;
                    detail.date_admission = req.body.dateAdmission;
                    detail.business_unit = req.body.businessUnit;
                    detail.contract_type_id = req.body.contractType;
                    detail.save();
                    return res.status(201).json({
                        message: 'Se creó el detalle'
                    });
                } else {
                    detail[0].update({
                        total_salary: req.body.totalSalary,
                        gross_salary: req.body.grossSalary,
                        additional_cost: req.body.additionalCost,
                        date_admission: req.body.dateAdmission,
                        business_unit: req.body.businessUnit,
                        contract_type_id: req.body.contractType
                    }).then(updated => {
                        messageResponse = 'Se actualizó correctamente';
                        return res.status(204).json({
                            message: messageResponse
                        });
                    });
                }
                res.status(201).json({
                    message: "Se actualizo correctamente"
                });
            })
            .catch(error => {
                res.json({
                    message: "Hubo un error al actualizar los detalles del usuario",
                    error: error
                });
            });
    } catch (error) {
        console.log(errror);
    }
}
//Eliminar usuario
function destroy(req, res) {
    if (res.params.id.length < 0) {
        res.status(400).json({
            message: "User id is required"
        });
    }
    User.destroy({
        where: {
            id: req.params.id
        }
    });
}

function changeStatus(req, res) {
    try {
        User.update({
                status_id: 2
            }, {
                where: {
                    id: req.params.id
                }
            })
            .then(update => {
                res.status(201).json({
                    message: "Se actualizo correctamente"
                });
                console.log("Se actualizó estado de usuario");
            })
            .catch(error => {
                res.json({
                    message: "Hubo un error al actualizar el usuario",
                    error: error
                });
            });
    } catch (error) {
        console.log(error);
    }
}

function login(req, res, next) {
    console.log(req.body.email);
    if (req.body.email.length < 0) {
        res.status(400).json({
            message: "Enter your email"
        });
    }
    if (req.body.password.length < 0) {
        res.status(400).json({
            message: "Enter your password"
        });
    }
    User.findAll({
            where: {
                email: req.body.email
            }
        })
        .then(user => {
            console.log("encontrado: " + JSON.stringify(user));
            if (user < 1) {
                return res.status(401).json({
                    message: "Authentication failed."
                });
            }

            bcrypt.compare(req.body.password, user[0].password, (err, result) => {
                if (err) {
                    return res.status(401).json({
                        message: "Authentication failed."
                    });
                }

                if (result) {
                    const token = jwt.sign({
                            email: user[0].email,
                            userId: user[0].id
                        },
                        process.env.JWT_KEY, {
                            expiresIn: "3h"
                        }
                    );

                    return res.status(200).json({
                        message: "Authentication is successfuly, to enjoy",
                        token: token,
                        userId: user[0].id,
                        rol: user[0].rol_id
                    });
                }

                res.status(401).json({
                    message: "Authentication failed"
                });
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
}

module.exports = {
    destroy,
    update,
    show,
    index,
    login,
    store,
    changeStatus
};