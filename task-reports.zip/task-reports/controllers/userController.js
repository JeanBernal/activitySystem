const bcrypt = require('bcrypt')
const path = require('path')
const jwt = require('jsonwebtoken')
const mongo = require("mongodb");
//const mailer = require(path.join(__dirname, '../controllers/mailerController'))

const User = require(path.join(__dirname, '../models/User'))
//PENDIENTE --> Registro de usuario passport google

//Crear usuario
function store (req, res) {
  try {
    const u_id = new mongo.ObjectID(req.params.userId)
  User.find({
    _id: u_id
  }).then(resp =>{
    if(resp.length != 1){
      return res.status(500).json({
        message: "User not found"
      })
    }
    var rol = resp[0].rol
    if(resp[0].rol != "admin"){
      return res.status(500).json({
        message: "Unauthorized"
      })
    }
    User.find({ 
      email: req.body.email
    }).then(user => {
      
      if (user.length >= 1) {
        return res.status(409).json({
            message: 'Already registered email'
        })
      }
      else{
        let pass = Math.random().toString(36).substring(7);
        console.log("random: ", pass);
        bcrypt.hash(pass, 10, (err, hash) => {
  
          if (err){
            return res.status(500).json({
              error:err
            })
          }
          else{
            const user = new User({
              name: req.body.name,
              email: req.body.email,
              rol:req.body.rol,
              password: hash
            })
            
            user.save().then((user) => {
              res.status(200).json({
                name:user.name,
                email:user.email,
                hash:hash
              })
              //mailer.info(user)
            }).catch((err) => {
              // res.status(500).json({
              //   error:err
              // })
            })
          }
        })
      }
  
    })
    
  })
  } catch (error) {
    console.log(error)
  }
}
//Logueo usuario
function login (req, res, next) {  

  User.find({ email: req.body.email }).then(user => {

    if (user < 1){
      return res.status(401).json({
        message:'Authentication failed.'
      })
    }

    bcrypt.compare(req.body.password, user[0].password, (err, result) => {

      if (err){
        return res.status(401).json({
          message:'Authentication failed.'
        })
      }

      if (result){
        
        const token = jwt.sign({
          email: user[0].email,
          userId: user[0]._id
        }
        ,
          process.env.JWT_KEY,
          {
              expiresIn: "3h"
          }
        )
      
        return res.status(200).json({
          message:'Authentication is successfuly, to enjoy',
          token: token,
          userId: user[0].id,
          rol: user[0].rol
        })
      }

      res.status(401).json({
        message:'Authentication failed'
      });
    
    })

  }).catch((err) =>  {
    res.status(500).json({
      error: err
    });
  })
}
//Listar usuarios
function index (req, res) {
  User.find({}, (err, users) => {
    res.json({
      data: users
    })
  })
}
//Mostrar usuairo por id
function show (req, res) {
  User.find({ _id: req.params.id }, (err, user) => {
    res.json({
      data: user[0]
    })
  })
}
//Actualizar usuario
function update (req, res) {

  let toUpdate = {
    name: req.body.name,
    email: req.body.email
  }

  User.updateOne({ _id: req.params.id }, toUpdate, (err, data) => {
    res.json({message: `User Updated`})
  })
}
//Eliminar usuario
function destroy (req, res) {
  
  User.deleteOne({ _id: req.params.id }, (err, data) => {
    res.json({message: `User Deleted`})
  })
}

module.exports = {
  destroy,
  update,
  show,
  index,
  login,
  store
}