const bcrypt = require("bcrypt");
const path = require("path");
const jwt = require("jsonwebtoken");
var DataTypes = require("sequelize/lib/data-types");
var connection = require("../config/db");
var sequelize = require("../config/db.js");
const Campaign = require("../models/campaign")(sequelize, DataTypes);
const User = require("../models/user")(sequelize, DataTypes);
const UnityClinetPro = require("../models/unity_client_project")(
  sequelize,
  DataTypes
);
const Client = require("../models/client")(sequelize, DataTypes);
const Unity = require("../models/unity")(sequelize, DataTypes);

function store(req, res) {
  console.log('Guardando campaña cliente ')
  console.log(req.body)
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      return res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    if (req.body.otherCampaign.length != 0) {
      for (let i = 0; i < req.body.otherCampaign.length; i++) {
        console.log("i" +  req.body.otherCampaign[i]);
        Campaign.findOne({
          where: { name: req.body.otherCampaign[i] }
        })
          .then(cam => {
            const campaign = Campaign.build({
              project_id: req.body.project_id,
              client_id: cam.client_id,
              name: cam.name,
              description: cam.description
            });
            campaign
              .save()
              .then(resp => {
                return res.status(201).json({
                  message: "ok"
                });
              })
              .catch(err => {
                console.log(err);
              });
          })
          .catch(err => {
            console.log(err)
          });
      }
    } else {
      const campaign = Campaign.build({
        project_id: req.body.project_id,
        client_id: req.body.client_id,
        name: req.body.name,
        description: req.body.description
      });

      campaign.save().then(resp => {
        return res.status(201).json({
          message: "ok"
        });
      });
    }
  } catch (error) {
    console.log(error);
  }
}

function index(req, res) {
  User.findAll({
    where: {
      id: req.params.id
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  Campaign.findAll({}).then(data => {
    res.json({
      data: data
    });
  });
}
//Mostrar usuairo por id
function show(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    }
  });
  Campaign.findAll({ where: { id: req.params.id } }).then(resp => {
    res.json({
      data: resp
    });
  });
}
//Actualizar usuario
function update(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  try {
    Campaign.update(
      {
        client_id: req.body.client_id,
        name: req.body.name,
        description: req.body.description
      },
      {
        where: {
          id: req.params.id
        }
      }
    ).then(update => {
      res.json({
        message: "Rol has been updated"
      });
    });
  } catch (error) {
    console.log(errror);
  }
}
//Eliminar usuario
function destroy(req, res) {
  User.findAll({
    where: {
      id: req.params.userId
    }
  }).then(user => {
    if (!user) {
      return res.status(500).json({
        message: "user not found"
      });
    } else if (user[0].rol_id != 1) {
      res.status(401).json({
        message: "Unauthorized"
      });
    }
  });
  Campaign.destroy({
    where: {
      id: req.params.id
    }
  });
}

function getProjectCampaign(req, res) {
  Campaign.belongsTo(Client, { foreignKey: "client_id" });
  console.log("Campañas del proyecto");
  Campaign.findAll({
    where: { project_id: req.params.projectId, status_id: 1 },
    include: [
      {
        model: Client,
        required: true
      }
    ]
  }).then(resp => {
    console.log(resp);
    res.json({
      data: resp
    });
  });
}

function getCampaignClient(req, res) {
  //
  console.log("clientes por campaña" + req.params.projectId);
  try {
    Client.hasMany(UnityClinetPro, { foreignKey: "client_id" });
    Client.hasMany(Campaign, { foreignKey: "client_id" });
    Client.findAll({
      where: {
        status_id: 1
      },
      include: [
        // {
        //   model: UnityClinetPro,
        //   where: {
        //     project_id: req.params.projectId
        //   },
        //   required: true
        // },
        {
          model: Campaign,
          where: {
            project_id: req.params.projectId,
            status_id: 1
          },
          required: true
        }
      ]
    })
      .then(unityClinetPro => {
        console.log(unityClinetPro);
        console.log(unityClinetPro[0].Campaigns);
        response = [];

        if (unityClinetPro.length > 0) {
          for (let j = 0; j < unityClinetPro.length; j++) {
            response[j] = {
              client: unityClinetPro[j].name,
              id: unityClinetPro[j].id
            };
            if (unityClinetPro[j].Campaigns.length > 0) {
              campaings = [];
              for (let i = 0; i < unityClinetPro[j].Campaigns.length; i++) {
                campaings[i] = {
                  name: unityClinetPro[j].Campaigns[i].name,
                  description: unityClinetPro[j].Campaigns[i].description,
                  id: unityClinetPro[j].Campaigns[i].id
                };
              }
              response[j].campaign = campaings;
            }
          }
        }
        res.status(200).json({
          message: response
        });
      })
      .catch(err => {
        console.log(err);
        res.send(err);
      });
  } catch (error) {
    console.log(error);
  }
}

function changeStatus(req, res) {
  console.log("Método para actualizar campaña" + req.params.id);
  try {
    Campaign.update(
      {
        status_id: 2
      },
      {
        where: {
          id: req.params.id
        }
      }
    )
      .then(update => {
        res.status(201).json({
          message: "Se actualizo correctamente"
        });
        console.log("Se actualizó estado de la campaña");
      })
      .catch(error => {
        res.json({
          message: "Hubo un error al actualizar la campaña",
          error: error
        });
      });
  } catch (error) {
    console.log(error);
  }
}

function otherCampaign(req, res) {

  UnityClinetPro.belongsTo(Client, { foreignKey: "client_id" });
  UnityClinetPro.belongsTo(Unity, { foreignKey: "unity_id" });
  console.log("Método para consultar las campañas de otras unidades clientes");
  try {
    data = [];
    dataUnityClient = [];
    UnityClinetPro.findAll({
      where: {
        unity_id: req.body.unity,
        client_id: req.body.client,
        status_id: 1
      },
      include: [
        {
          model: Client,
          attributes: ["name"],
          required: true
        },
        {
          model: Unity,
          attributes: ["name"],
          required: true
        }
      ]
    }).then(unityClient => {
      for (let i = 0; i < unityClient.length; i++) {
        data[i] = unityClient[i].project_id;
      }
      console.log(unityClient[0].Client.name)
      dataUnityClient = {
         client: unityClient[0].Client.name,
         unity: unityClient[0].Unity.name
      };
      Campaign.findAll({
        attributes: [sequelize.literal('DISTINCT `name`'), 'name'],
        where: { 
          project_id: data,
          client_id: req.body.client,
        }
      }).then(campaings => {
        console.log(data);
        return res.json({
          message: "Ok",
          data: campaings,
          dataUC: dataUnityClient
        });
      });
    });
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  destroy,
  update,
  show,
  index,
  store,
  getCampaignClient,
  getProjectCampaign,
  changeStatus,
  otherCampaign
};
