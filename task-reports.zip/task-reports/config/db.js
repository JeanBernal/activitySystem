const mongoose = require("mongoose");
const dotenv = require("dotenv");
const mysql = require("mysql");
const Sequelize = require("sequelize");

dotenv.config();

// Conectando a la base de mongo
// module.exports = mongoose.connection.on("connected", function() {
//   console.log("Database is connected");
// });
// console.log(process.env.DB_CONNECT);
// mongoose.connect(process.env.DB_CONNECT, { userNewUrlParser: true }, err => {
//   if (err) {
//     console.log(err);
//   }
// });

//Conectando a la base de MySQL (db para almacenar información de twitter y tratada en data studio)
const sequelize = new Sequelize(
  process.env.DB_MYSQL,
  process.env.DB_MYSQL_USER,
  process.env.DB_MYSQL_PASSWORD,
  {
    host: process.env.DB_MYSQL_HOST,
    port: 3306,
    dialect: "mysql"
  }
);
sequelize
  .authenticate()
  .then(() => {
    console.log("Conectado");
  })
  .catch(err => {
    console.log("No se conectó");
    console.log(err);
  });

module.exports = sequelize;


