'use restrict';

(async function run () {

  async function saveFunction(data) {
    const fncModel = require('../models/Function')
    const mdl = new fncModel(data)
    return await mdl.save().then(res => res._id).catch(err => console.log(err))
  }

  const datasToSave = [
    {
      name: 'Solicitud a internet',
      inputs: '',
      code: `var request = require('request-promise'); var response = await request({ url: 'https://jsonplaceholder.typicode.com/posts/42', json: true });`
    },
    {
      name: 'Concatenacion',
      inputs: 'name,lastname',
      code: `var response = \`\${inputs.name} \${inputs.lastname}\``
    },
    {
      name: 'Ambas simultaneamente',
      inputs: 'name, lastname',
      code: `var request = require("request-promise"); var fuente1 = request({   method: "POST",   url: "http://localhost:8000/api/function/launch/5d42f7638c7a9301626f4680",   json: true }); var fuente2 = request({   method: "POST",   url: "http://localhost:8000/api/function/launch/5d430ac66a5ff01d08ffc2fc",   body: { inputs: { name: inputs.name, lastname: inputs.lastname } },   json: true }); var response = await Promise.all([fuente1, fuente2]);`
    }
  ]
  console.log('Starting')
  return Promise.all(datasToSave.map(data => saveFunction(data)))
    .then(dataSaved => console.log('Functions saved with ids: ', dataSaved))
    .catch(err => console.error('Error saving functions: ', err))
})()