"use strict";

const prompts = require("prompts");
const path = require("path");
const fs = require("fs");

(async function() {
  const questions = [
    {
      type: "toggle",
      name: "JWT_KEY",
      message: "Do you want to generate an random App Key?",
      active: "Yes",
      inactive: "No"
    },
    {
      type: "text",
      name: "DB_CONNECT",
      message: `What is the database URL (Mongo)?`,
      initial: 'mongodb://localhost:27017/demodb'
    }
  ];

  const answers = await prompts(questions, { onCancel: cleanup });
  process_answers(answers);
})();

function process_answers(answers) {
  const copyFile = require("../tools/copyFile");

  const existent = fs.existsSync(path.join(".env"));

  if (!existent) copyFile(path.join(".env.example"), path.join(".env"), () => readFileProccess(answers))
  else readFileProccess(answers)
}

async function readFileProccess(answers) {
  const readLines = require("../tools/readLines");
  const randomstring = require("randomstring");
  const env_lines = await readLines(path.join(".env"));

  if (answers["JWT_KEY"] || !env_lines.length)
    answers["JWT_KEY"] = randomstring.generate();
  else delete answers["JWT_KEY"];

  const final_lines = env_lines.map(env => ({
    key: env.split("=")[0].trim(),
    value: env.split("=").length > 1 ? env.split("=")[1].trim() : null
  }));

  for (const key in answers) {
    if (answers.hasOwnProperty(key)) {
      const value = answers[key];
      if (final_lines.find(line => line.key === key))
        final_lines[
          final_lines.findIndex(line => line.key === key)
        ].value = value;
      else final_lines.push({ key, value });
    }
  }

  const final_string = final_lines.map((line, i, arr) => `${line.key}=${line.value}${i < (arr.length - 1) ? '\n' : ''}`).join('');
  fs.writeFileSync(path.join(".env"), final_string);
  console.log(".env file was updated.")
}

function cleanup() {
  console.log("Cleaning prompt.");
}
