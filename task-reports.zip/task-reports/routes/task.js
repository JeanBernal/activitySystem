'use restrict'

const route = require('express').Router()
const path = require('path')
const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))
const taskCtr = require(path.join(__dirname, '../controllers/taskCtr'))

route.post('/create/:userId', taskCtr.store)
route.post('/fulfilment/:userId', taskCtr.fulfilment)
route.get('/:userId', taskCtr.index)
route.post('/:userId/', taskCtr.getTaskFilterDate)
route.put('/:id/:userId', taskCtr.update)
route.get('/:userId/:id', taskCtr.show)

// route.post('/fulfilment/:userId', taskCtr.fulfilment)


module.exports = route