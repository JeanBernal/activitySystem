'use restrict'

const route = require('express').Router()
const path = require('path')
const ContractTypeController = require(path.join(__dirname, '../controllers/contractTypeCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:userId', ContractTypeController.store)
route.get('/:userId',ContractTypeController.index)




module.exports = route