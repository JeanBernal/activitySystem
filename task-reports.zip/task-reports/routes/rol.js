'use restrict'

const route = require('express').Router()
const path = require('path')
const rolCtr = require(path.join(__dirname, '../controllers/rolCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', rolCtr.store)
route.get('/:id',rolCtr.index)
route.get('/:userId/:id', rolCtr.show)
route.put('/:userId/:id', rolCtr.update)
route.delete('/:userId/:id', rolCtr.destroy)




module.exports = route
