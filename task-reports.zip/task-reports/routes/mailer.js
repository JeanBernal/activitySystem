// 'use restrict'

// const route = require('express').Router()
// const path = require('path')
// const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))
// const mailerController = require(path.join(__dirname, '../controllers/mailerController'))

// route.post('/mailer', mailerController.sendEmail)





// module.exports = route
