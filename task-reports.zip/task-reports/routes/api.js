'use restrict'

const path = require('path')
const route = require('express').Router()

route.use('/user', require(path.join(__dirname, '/user')))
route.use('/project', require(path.join(__dirname, '/project')))
route.use('/task', require(path.join(__dirname, '/task')))
route.use('/monthHours', require(path.join(__dirname, '/monthHours')))
route.use('/metric', require(path.join(__dirname, '/metric')))
route.use('/rol', require(path.join(__dirname, '/rol')))
route.use('/client', require(path.join(__dirname, '/client')))
route.use('/profile',require(path.join(__dirname,'/profile')))
route.use('/unity',require(path.join(__dirname,'/unity')))
route.use('/phase',require(path.join(__dirname,'/phase')))
route.use('/campaign',require(path.join(__dirname,'/campaign')))
route.use('/costcenter',require(path.join(__dirname,'/costcenter')))
route.use('/holdingcompany',require(path.join(__dirname,'/holdingcompany')))
route.use('/hoursformonth',require(path.join(__dirname,'/hoursformonth')))
route.use('/unity_client_project',require(path.join(__dirname,'/unity_client_project')))
// route.use('/dashboard',require(path.join(__dirname,'/dashboard')))
route.use('/campaignphaseuser',require(path.join(__dirname,'/campaignphaseuser')))
route.use('/contractType',require(path.join(__dirname,'/contractType')))
route.use('/historic',require(path.join(__dirname,'/historic')))

// route.use('/mailer', require(path.join(__dirname, '/mailer')))


module.exports = route