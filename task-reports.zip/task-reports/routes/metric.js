'use restrict'

const route = require('express').Router()
const path = require('path')
const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))
const metricsController = require(path.join(__dirname, '../controllers/metricsController'))

route.get('/hourControl/:userId', metricsController.hourControl)





module.exports = route
