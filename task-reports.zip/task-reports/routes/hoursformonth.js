'use restrict'

const route = require('express').Router()
const path = require('path')
const hoursForMonthCtr = require(path.join(__dirname, '../controllers/hoursForMonthCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', hoursForMonthCtr.store)
route.get('/:id',hoursForMonthCtr.index)
route.get('/:userId/:id', hoursForMonthCtr.show)
route.put('/:userId/:id', hoursForMonthCtr.update)
route.delete('/:userId/:id', hoursForMonthCtr.destroy)



module.exports = route
