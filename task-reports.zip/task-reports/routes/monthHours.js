'use restrict'

const route = require('express').Router()
const path = require('path')
const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))
const monthHoursController = require(path.join(__dirname, '../controllers/monthHoursController'))

route.post('/create', monthHoursController.store)
route.get('/:id', monthHoursController.index)

module.exports = route
