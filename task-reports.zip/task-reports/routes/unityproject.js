'use restrict'

const route = require('express').Router()
const path = require('path')
const unity_ProjectCtr = require(path.join(__dirname, '../controllers/unity_ProjectCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', unity_ProjectCtr.store)
route.get('/:id',unity_ProjectCtr.index)
route.get('/:userId/:id', unity_ProjectCtr.show)
route.put('/:userId/:id', unity_ProjectCtr.update)
route.delete('/:userId/:id', unity_ProjectCtr.destroy)



module.exports = route
