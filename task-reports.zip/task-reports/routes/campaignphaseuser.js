'use restrict'

const route = require('express').Router()
const path = require('path')
const campaignPhaseUserCtr = require(path.join(__dirname, '../controllers/campaignPhaseUserCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', campaignPhaseUserCtr.changeStatus)
route.post('/create/:id', campaignPhaseUserCtr.store)
route.get('/:userId/:id',campaignPhaseUserCtr.index)
route.get('/show/:userId/:id', campaignPhaseUserCtr.show)
route.put('/:userId/:id', campaignPhaseUserCtr.update)
route.delete('/:userId/:id', campaignPhaseUserCtr.destroy)
route.get('/projectCampaign/:userId/:id', campaignPhaseUserCtr.projectCampaign)

module.exports = route
