'use restrict'

const route = require('express').Router()
const path = require('path')
const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))
const costCenterCtr = require(path.join(__dirname, '../controllers/costCenterCtr'))

route.put('/change/status/:id', costCenterCtr.changeStatus)
route.post('/create/:id', costCenterCtr.store)
route.get('/:userId', costCenterCtr.index)
route.put('/:userId/:id', costCenterCtr.update)
//route.get('/:userId', costCenterCtr.list)





module.exports = route
