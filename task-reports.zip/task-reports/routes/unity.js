'use restrict'

const route = require('express').Router()
const path = require('path')
const unityCtr = require(path.join(__dirname, '../controllers/unityCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', unityCtr.changeStatus)
route.post('/create/:id', unityCtr.store)
route.get('/:id',unityCtr.index)
route.get('/:userId/:id', unityCtr.show)
route.put('/:userId/:id', unityCtr.update)
route.delete('/:userId/:id', unityCtr.destroy)



module.exports = route
