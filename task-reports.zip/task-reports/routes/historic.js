'use restrict'

const route = require('express').Router()
const path = require('path')
const historicCtr = require(path.join(__dirname, '../controllers/historicCtr'))
    //const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.get('/', historicCtr.historicQuery);
route.get('/prueba', historicCtr.historyData);
route.post('/info/:userId', historicCtr.getTaskInfo);


module.exports = route