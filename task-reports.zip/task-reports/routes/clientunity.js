'use restrict'

const route = require('express').Router()
const path = require('path')
const unity_ClientCtr = require(path.join(__dirname, '../controllers/unity_ClientCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', unity_ClientCtr.store)
route.get('/:id',unity_ClientCtr.index)
route.get('/:userId/:id', unity_ClientCtr.show)
route.put('/:userId/:id', unity_ClientCtr.update)
route.delete('/:userId/:id', unity_ClientCtr.destroy)



module.exports = route
