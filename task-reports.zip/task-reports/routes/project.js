'use restrict'

const route = require('express').Router()
const path = require('path')
const projectCtr = require(path.join(__dirname, '../controllers/projectCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', projectCtr.changeStatus)
route.post('/create/:id', projectCtr.store)
route.get('/:id',projectCtr.index)
route.get('/details/:userId/:id', projectCtr.detailProject)
route.get('/:userId/:id', projectCtr.show)
route.put('/:userId/:id', projectCtr.update)
route.delete('/:userId/:id', projectCtr.destroy)


module.exports = route
