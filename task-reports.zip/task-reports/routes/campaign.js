'use restrict'

const route = require('express').Router()
const path = require('path')
const campaignCtr = require(path.join(__dirname, '../controllers/campaignCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', campaignCtr.changeStatus)
route.post('/create/:id', campaignCtr.store)
route.post('/other/campaign',campaignCtr.otherCampaign)
route.get('/:id',campaignCtr.index)
route.get('/project/:projectId', campaignCtr.getProjectCampaign)
route.get('/:userId/:id', campaignCtr.show)
route.put('/:userId/:id', campaignCtr.update)
route.delete('/:userId/:id', campaignCtr.destroy)
route.get('/client/campaign/:projectId', campaignCtr.getCampaignClient)


module.exports = route
