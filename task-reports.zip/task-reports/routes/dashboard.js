'use restrict'

const route = require('express').Router()
const path = require('path')
const dashboardCtr = require(path.join(__dirname, '../controllers/dashboardCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.get('/projects/:id/:userId', dashboardCtr.filterProjects)




module.exports = route