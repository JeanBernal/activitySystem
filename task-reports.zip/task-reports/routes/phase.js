'use restrict'

const route = require('express').Router()
const path = require('path')
const phaseCtr = require(path.join(__dirname, '../controllers/phaseCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', phaseCtr.store)
route.get('/:id',phaseCtr.index)
route.get('/:userId/:id', phaseCtr.show)
route.put('/:userId/:id', phaseCtr.update)
route.delete('/:userId/:id', phaseCtr.destroy)



module.exports = route
