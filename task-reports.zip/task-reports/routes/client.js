'use restrict'

const route = require('express').Router()
const path = require('path')
const clientCtr = require(path.join(__dirname, '../controllers/clientCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', clientCtr.store)
route.get('/:id',clientCtr.index)
route.get('/:userId/:id', clientCtr.show)
route.put('/:userId/:id', clientCtr.update)
route.delete('/:userId/:id', clientCtr.destroy)




module.exports = route
