'use restrict'

const route = require('express').Router()
const path = require('path')
const holdingCompanyCtr = require(path.join(__dirname, '../controllers/holdingCompanyCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', holdingCompanyCtr.changeStatus)
route.post('/create/:id', holdingCompanyCtr.store)
route.get('/:id',holdingCompanyCtr.index)
route.get('/:userId/:id', holdingCompanyCtr.show)
route.put('/:userId/:id', holdingCompanyCtr.update)
route.delete('/:userId/:id', holdingCompanyCtr.destroy)

module.exports = route
