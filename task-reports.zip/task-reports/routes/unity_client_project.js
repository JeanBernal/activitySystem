'use restrict'

const route = require('express').Router()
const path = require('path')
const unity_Client_ProjectCtr = require(path.join(__dirname, '../controllers/unity_Client_ProjectCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', unity_Client_ProjectCtr.changeStatus)
route.post('/create/:id', unity_Client_ProjectCtr.store)
route.get('/:userId/:id',unity_Client_ProjectCtr.index)
route.get('/show/:userId/:id', unity_Client_ProjectCtr.show)
route.put('/:userId/:id', unity_Client_ProjectCtr.update)
route.delete('/:userId/:id', unity_Client_ProjectCtr.destroy)




module.exports = route
