'use restrict'

const route = require('express').Router()
const path = require('path')
const userCtr = require(path.join(__dirname, '../controllers/userCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.put('/change/status/:id', userCtr.changeStatus)
route.post('/create/:id', userCtr.store)
route.get('/',userCtr.index)
route.post('/login',userCtr.login)
route.get('/:id', userCtr.show)
route.put('/:id', userCtr.update)
route.delete('/:id', userCtr.destroy)




module.exports = route
