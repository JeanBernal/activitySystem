'use restrict'

const route = require('express').Router()
const path = require('path')
const profileCtr = require(path.join(__dirname, '../controllers/profileCtr'))
//const checkAuth = require(path.join(__dirname, '../middleware/checkAuth'))

route.post('/create/:id', profileCtr.store)
route.get('/:id',profileCtr.index)
route.get('/:userId/:id', profileCtr.show)
route.put('/:userId/:id', profileCtr.update)
route.delete('/:userId/:id', profileCtr.destroy)



module.exports = route
