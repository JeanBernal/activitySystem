'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('ContractTypes', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_ContractTypes_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('ContractTypes', 'FK_ContractTypes_Status')
    
   }
};

