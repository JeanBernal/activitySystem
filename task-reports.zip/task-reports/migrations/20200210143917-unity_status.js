'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('Unitys', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_Unitys_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Unitys', 'FK_Unitys_Status')
    
   }
};

