'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('CampaignPhaseUsers', ['campaign_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Campaign_Campaign_Phase_User',
      references: {
        table: 'Campaigns',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('CampaignPhaseUsers', 'FK_Campaign_Campaign_Phase_User')
  }
};