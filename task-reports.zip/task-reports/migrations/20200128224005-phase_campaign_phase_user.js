'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('CampaignPhaseUsers', ['phase_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Phase_Campaign_Phase_User',
      references: {
        table: 'Phases',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('CampaignPhaseUsers', 'FK_Phase_Campaign_Phase_User')
  }
};
