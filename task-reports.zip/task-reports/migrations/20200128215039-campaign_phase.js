'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('PhaseCampaigns', ['campaign_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Campaign_Phase',
      references: {
        table: 'Campaigns',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('PhaseCampaigns', 'FK_Campaign_Phase')
  }
};
