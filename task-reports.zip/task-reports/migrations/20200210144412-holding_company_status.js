'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('HoldingCompanies', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_HoldingCompanies_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('HoldingCompanies', 'FK_HoldingCompanies_Status')
    
   }
};

