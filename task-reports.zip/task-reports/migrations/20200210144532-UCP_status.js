'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('unity_client_projects', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_unity_client_projects_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
         onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('unity_client_projects', 'FK_unity_client_projects_Status')
    
   }
};

