'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Historics', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      project_id: {
        type: Sequelize.INTEGER
      },
      project_name: {
        type: Sequelize.STRING
      },
      unity_id: {
        type: Sequelize.INTEGER
      },
      unity_name: {
        type: Sequelize.STRING
      },
      client_id: {
        type: Sequelize.INTEGER
      },
      client_name: {
        type: Sequelize.STRING
      },
      campaign_id: {
        type: Sequelize.INTEGER
      },
      campaign_name: {
        type: Sequelize.STRING
      },
      user_id: {
        type: Sequelize.INTEGER
      },
      user_name: {
        type: Sequelize.STRING
      },
      user_salary: {
        type: Sequelize.DOUBLE
      },
      task_id: {
        type: Sequelize.INTEGER
      },
      task_activity: {
        type: Sequelize.STRING
      },
      task_hours: {
        type: Sequelize.FLOAT
      },
      task_date: {
        type: Sequelize.DATE
      },
      task_day: {
        type: Sequelize.INTEGER
      },
      task_month: {
        type: Sequelize.INTEGER
      },
      task_year: {
        type: Sequelize.INTEGER
      },
      user_cost: {
        type: Sequelize.INTEGER
      },
      phase_name: {
        type: Sequelize.STRING
      },
      hoursDistribution: {
        type: Sequelize.DOUBLE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Historics');
  }
};