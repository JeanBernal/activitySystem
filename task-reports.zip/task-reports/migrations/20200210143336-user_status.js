'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('Users', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_User_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
         onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Users', 'FK_User_Status')
    
   }
};

