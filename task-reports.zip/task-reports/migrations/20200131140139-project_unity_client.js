'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('unity_client_projects', ['project_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_project_unity_client',
      references: {
        table: 'Projects',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('unity_client_projects', 'FK_project_unity_client')
  }
};