'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('Profiles', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_Profiles_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
          onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Profiles', 'FK_Profiles_Status')
    
   }
};

