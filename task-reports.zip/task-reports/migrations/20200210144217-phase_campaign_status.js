'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('PhaseCampaigns', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_PhaseCampaigns_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('PhaseCampaigns', 'FK_PhaseCampaigns_Status')
    
   }
};

