'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Projects', ['holding_company_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Project_Holding_Companys',
      references: {
        table: 'HoldingCompanies',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Projects', 'FK_Project_Holding_Companys')
  }
};