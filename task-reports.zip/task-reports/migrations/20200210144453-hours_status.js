'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('HoursForMonths', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_HoursForMonths_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('HoursForMonths', 'FK_HoursForMonths_Status')
    
   }
};

