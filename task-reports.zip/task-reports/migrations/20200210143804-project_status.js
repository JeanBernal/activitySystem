'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('Projects', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_Projects_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Projects', 'FK_Projects_Status')
    
   }
};

