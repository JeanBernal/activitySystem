'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('PhaseCampaigns', ['phase_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Phase_Campaign',
      references: {
        table: 'Phases',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('PhaseCampaigns', 'FK_Phase_Campaign')
  }
};
