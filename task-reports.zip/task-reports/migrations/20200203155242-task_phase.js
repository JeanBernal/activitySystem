'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Tasks', ['phase_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Task_Phase',
      references: {
        table: 'Phases',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Tasks', 'FK_Task_Phase')
  }
};
