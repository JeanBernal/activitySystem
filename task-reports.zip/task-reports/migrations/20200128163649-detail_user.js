'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Details', ['user_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Detail_User',
      references: {
        table: 'Users',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Details', 'FK_Detail_User')
  }
};
