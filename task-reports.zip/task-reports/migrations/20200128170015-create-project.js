'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Projects', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      user_id: {
        type: Sequelize.INTEGER
      },
      cost_center_id:{
        type:Sequelize.INTEGER
      },
      holding_company_id: {
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      nit: {
        type: Sequelize.INTEGER
      },
      category: {
        type: Sequelize.STRING
      },
      objective_project: {
        type: Sequelize.STRING
      },
      use_type: {
        type: Sequelize.STRING
      },
      intellectual_property: {
        type: Sequelize.STRING
      },
      licensed: {
        type: Sequelize.STRING
      },
      finality: {
        type: Sequelize.STRING
      },
      monthly_fee: {
        type: Sequelize.STRING
      },
      monthly_fee_cost: {
        type: Sequelize.INTEGER
      },
      status_id:{
        type: Sequelize.INTEGER,
        defaultValue: 1
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Projects');
  }
};