'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Details', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      user_id: {
        type: Sequelize.INTEGER
      },
      total_salary: {
        type: Sequelize.DOUBLE
      },
      gross_salary: {
        type: Sequelize.DOUBLE
      },
      additional_cost: {
        type: Sequelize.DOUBLE
      },
      date_admission: {
        type: Sequelize.DATE
      },
      business_unit: {
        type: Sequelize.STRING
      },
      contract_type_id: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Details');
  }
};