'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('Campaigns', ['client_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Campaign_Client',
      references: {
        table: 'Clients',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Campaigns', 'FK_Campaign_Client')
  }
};
