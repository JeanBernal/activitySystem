'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
   
     
     
    return queryInterface.addConstraint('Users', ['rol_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_User_Rol',
         references: {
           table: 'Rols',
           field: 'id'
         },
         onDelete: 'no action',
         onUpdate: 'no action'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Users', 'FK_User_Rol')
    
   }
};
