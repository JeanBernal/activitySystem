'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('CampaignPhaseUsers', ['user_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_User_Campaign_Phase_User',
      references: {
        table: 'Users',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('CampaignPhaseUsers', 'FK_User_Campaign_Phase_User')
  }
};
