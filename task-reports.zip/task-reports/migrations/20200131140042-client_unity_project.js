'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {     
    return queryInterface.addConstraint('unity_client_projects', ['client_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_client_unity_project',
      references: {
        table: 'Clients',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('unity_client_projects', 'FK_client_unity_project')
  }
};