'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Tasks', ['user_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Task_User',
      references: {
        table: 'Users',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Tasks', 'FK_Task_User')
  }
};