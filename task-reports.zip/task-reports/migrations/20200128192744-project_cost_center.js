'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Projects', ['cost_center_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Project_Cost_Center',
      references: {
        table: 'CostCenters',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Projects', 'FK_Project_Cost_Center')
  }
};
