'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
       
    return queryInterface.addConstraint('Phases', ['status_id'],{
         type: 'FOREIGN KEY',
         name: 'FK_Phases_Status',
         references: {
           table: 'Status',
           field: 'id'
         },
      onDelete: 'no action',
         onUpdate: 'cascade'
       })
    
  },

  down: (queryInterface, Sequelize) => {
    
    return queryInterface.removeConstraint('Phases', 'FK_Phases_Status')
    
   }
};

