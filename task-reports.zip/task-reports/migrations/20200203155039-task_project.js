'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addConstraint('Tasks', ['project_id'],{
      type: 'FOREIGN KEY',
      name: 'FK_Task_Project',
      references: {
        table: 'Projects',
        field: 'id'
      },
      onDelete: 'no action',
      onUpdate: 'no action'
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeConstraint('Tasks', 'FK_Task_Project')
  }
};
