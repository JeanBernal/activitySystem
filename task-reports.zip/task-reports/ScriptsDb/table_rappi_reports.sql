CREATE TABLE alquimia_api.rappi_reports (
	id BIGINT NOT NULL AUTO_INCREMENT,
	frequency varchar(100) NOT NULL,
	start_date DATE NOT NULL,
	finished_date DATE NOT NULL,
	`hour` varchar(100) NOT NULL,
	key_word varchar(100) NOT NULL,
	createdAt TIMESTAMP NULL,
	updatedAt TIMESTAMP NULL,
	CONSTRAINT rappi_reports_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8
COLLATE=utf8_spanish2_ci;
