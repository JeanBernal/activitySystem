CREATE TABLE alquimia_local.twits (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_twit varchar(255) NOT NULL,
	id_str varchar(255) NULL,
	`text` LONGTEXT NOT NULL,
	retweet_count INT NULL,
	favorite_count INT NULL,
	mentions_count INT NULL,
	screen_name varchar(255) NULL,
	twit_link varchar(255) NULL,
	`date` DATE NOT NULL,
	createdAt TIMESTAMP NOT NULL,
	updatedAt TIMESTAMP NOT NULL,
	CONSTRAINT twits_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_spanish2_ci;

ALTER TABLE alquimia_local.twits CHANGE created_at createdAt timestamp NOT NULL;
ALTER TABLE alquimia_local.twits CHANGE updated_at updatedAt timestamp NOT NULL;
