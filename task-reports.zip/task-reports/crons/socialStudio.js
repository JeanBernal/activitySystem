//var cron = require('node-cron');
const path = require("path");
const ss = require(path.join(__dirname, "../controllers/workSpaceController"));
 

  console.log('recibe')



// try {
//   cron.schedule('* * * * * *', () => {
//     var tk = ss.reportRun()
//     console.log(tk)
//   });
// } catch (error) {
//   console.log(error)
// }
