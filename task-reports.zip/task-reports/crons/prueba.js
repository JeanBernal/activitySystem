var cron = require('node-cron');
// const path = require("path");
// const a = require(path.join(__dirname, "../controllers/pruebaCron"));
 
// cron.schedule('* * * * * *', () => {
//     a.prueba();
// });

// let now = new Date("December 15, 2019 22:51:00")
// let b = 'asad'
// let hour = now.getHours()
// let min = now.getMinutes()
// console.log(now)
// console.log(hour)
// console.log(min)


    // var a = 2
    // var h = 5
    // function d(){
    //     return h
    // }
    // // console.log(a)
    // if (a == 1) {
    //     cron.schedule("* * * * * *", () => {
    //         console.log('1')
    //     })
    // }else{
    //     cron.schedule(h+'* * * * * *', () => {
    //         console.log('2')
    //     })
    // }

    function tarea(){
        console.log('acá va la tarea', new Date());
    }
    
    function lanzarElDia(momento, tarea){
        console.log('lanzado',new Date());
        console.log('para ser ejecutado en',momento);
        setTimeout(tarea, momento.getTime()-(new Date()).getTime());
    }
    
    lanzarElDia(new Date('2019-12-19 15:24'), tarea);
    


//module.exports = {prueba}5960050   15029