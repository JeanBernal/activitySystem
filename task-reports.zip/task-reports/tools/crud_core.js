function CRUDMongose (model) {
  return {

    index (req, res, next) {
      model.query(req.query, function(err, data){
        if(err) return next(err);
        res.json({ data });
      })
    },
    
    show (req, res, next) {
      model.find({ _id: req.params.id }, (err, data) => {
        if(err) return next(err);
        res.json({ data: data[0] })
      })
    },

    store (req, res, next) {
      const mdl = new model(req.body)
      mdl.save()
        .then(result => res.json(result))
        .catch(err => next(err))
    },
    
    update (req, res) {
      model.updateOne({ _id: req.params.id }, { ...req.body }, (err, data) => {
        if(err) return next(err);
        res.json({ message: `Registry Updated`, data })
      })
    },
    
    destroy (req, res, next) {
      User.deleteOne({ _id: req.params.id }, {}, (err, data) => {
        if(err) return next(err);
        res.json({ message: `Registry Deleted`, data })
      })
    }
  }
}

module.exports = {
  CRUDMongose
}