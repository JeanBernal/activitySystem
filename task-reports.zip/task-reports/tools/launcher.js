var childProcess = require("child_process");
var path = require('path');

/** EXAMPLE OF USE
 * 
 *  var launcher = require('../tools/launcher');
    launcher({
      fnc: 'function(info){ result = "dd " + info; }',
      data: 'Andres'
    }).then(reso => {
      console.log('Received', reso);
      res.send(reso)
    }).catch(err => {
      res.sendStatus(500);
    })
 */

/**
 * 
 * @param {Object} toSend Contains function string and params
 */
function launcher(toSend) {
  return new Promise((resolve, reject) => {
    var pr = childProcess.fork(path.join(__dirname, './sandbox.js'));
    pr.send(toSend);
    pr.on('message', data => {
      if (data.error) reject(data)
      resolve(data.data)
      pr.kill();
    })
  });
}

module.exports = launcher;
