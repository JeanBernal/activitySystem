module.exports = function readLines(url) {
    return new Promise(resolve => {
      const fs = require("fs");
      const input = fs.createReadStream(url, "utf8");
      var remaining = "";
      var lines = [];
  
      input.on("data", function(data) {
        remaining += data;
        var index = remaining.indexOf("\n");
        var last = 0;
        while (index > -1) {
          var line = remaining.substring(last, index);
          last = index + 1;
          lines.push(line.trim());
          index = remaining.indexOf("\n", last);
        }
  
        remaining = remaining.substring(last);
      });
  
      input.on("end", function() {
        if (remaining.length > 0) {
          lines.push(remaining.trim())
        }
        resolve(lines);
      });
    });
  }