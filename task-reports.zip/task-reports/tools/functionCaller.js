const launcher = require('./launcher')
const _ = require('lodash')
const fncModel = require('../models/Function')

module.exports = function (_id, bodyInputs = {}) {
  return new Promise((resolve, reject) => {
    if (bodyInputs === null) bodyInputs = {}
    fncModel.find({ _id }, (err, data) => {
      if(err) return reject(err);
      const code = _.get(data, '[0].code')
      let inputs = _.get(data, '[0].inputs', '')
      if (inputs !== '') {
        inputs = inputs
          .split(',')
          .map(elm => elm.trim())
      } else {
      }
      if (Array.isArray(inputs) && !inputs.reduce((prev, curr) => !!bodyInputs[curr] && prev, true)) {
        return reject({ message: 'Inputs are incomplete!', inputs, bodyInputs, id });
      }
      return launcher({
        fnc: code,
        data: bodyInputs
      }).then(resolve).catch(reject)
    })
  })
}