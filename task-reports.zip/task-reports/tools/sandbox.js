const _ = require("lodash");

function sandbox(code, inputs) {
  return new Promise((resolve, reject) => {
    var vm = require("vm");
  
    // VM context object
    var context = {
      require,
      callback: function(error) {
        if (error) {
          reject(error.stack)
        } else {
          resolve(this.response);
        }
      },
      inputs
    };
  
    // Wrap the code
    code = `
      'use strict';
      async function run() {
        try {
          ${code.replace(/var /g, "this.")}
          this.callback(null);
        } catch(error) {
          this.callback(error);
        }
      };
      run.apply(this);
    `
    var regeneratedCode = code
  
    // Create VM context
    var vmContext = new vm.createContext(context);
  
    // Create virtual script
    var script = new vm.Script(regeneratedCode);
  
    // Run script
    script.runInContext(vmContext, { displayErrors: true, timeout: 30000 });
  });
}

process.on("message", async data => {
  if (_.get(data, "halt") || !_.get(data, "fnc")) process.exit(0);
  else {
    try {
      const result = await sandbox(_.get(data, "fnc"), _.get(data, "data", {}));
      process.send({ data: result });
    } catch (error) {
      console.log(error)
      process.send({ error });
    }
  }
});
